%Responsible person: Ioannis Peppas
%Contact: Ioannis.Peppas-EE@infineon.com

classdef loadpullData < handle
    
    properties (Access = public)
        %% 
        pullType %string 'O1', 'O2', 'O3', 'I1', 'I2', 'I3' 
        
        %% frequency data
        Freq %Frequency vector. Frequencies in Hz.
        
        %% Loadpull Data
        data
        dataFormat
        
        %% Port 1 Reference Impedance
        Zref1
        
        %% Port 2 Reference Impedance
        Zref2
    end
    
    properties (Access = private)
        inputPortNumber = 1;
        outputPortNumber = 2;
    end
    
    methods (Access = public)
        
        function obj = loadpullData(pullType, FrequencyVector, ZrefPort1, ZrefPort2)
            %Construct an instance of this class
            %Freq Frequency Vector in Hz
            %Zref1 reference impedance of port1
            %Zref2 reference impedance of port2
            
            obj.Freq = FrequencyVector;
            obj.Zref1 = ZrefPort1;
            obj.Zref2 = ZrefPort2;
            
            if sum(strcmpi({'O1', 'O2', 'O3', 'I1', 'I2', 'I3', 'unavailable'}, pullType))
                obj.pullType = char(pullType);
            else
                disp('Error: pullType should be O1, O2, O3, I1, I2, I3 or unavailable')
            end
            
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% FOCUS MICROWAVE TOOLS
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %File importing/exporting tools
        
        function import_FOCUS_MICROWAVE_FORMAT(obj, fileName, fileType)
            if (strcmp(fileType,"MDIF"))
                [obj.data,obj.dataFormat] = obj.importMDIF_v1p0(fileName);
                
            elseif (strcmp(fileType,"LPCWAVE"))
                [obj.data,obj.dataFormat] = obj.importLPCWAVE_v1p0(fileName);
                
            elseif (strcmp(fileType,""))
                %the data will be manually inserted
                %do nothing here
                disp('Manual data definition.')
                
            else
                disp('Unknown data format!')
                
            end
        end
        
        function importUnits_FOCUS_MICROWAVE_FORMAT(obj, exampleFileName)
            %  This function can be used to import measurement units.
            %  
            %  MDIF files DO NOT preserve measurement units for block
            %  variables. However LPCwave files DO preserve measurement
            %  units. If the measurement units are needed, they can be
            %  recovered from an 'example' file with LPCwave format as long
            %  as the block variable names are preserved between the
            %  imported and 'example' files.
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section A: import example lpcwave file
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            file=readcell(exampleFileName,'FileType','text', ...
                'CommentStyle','!', ...
                'Delimiter',{'\t',' '}, ...
                'ConsecutiveDelimitersRule','join', ...
                'LeadingDelimitersRule','ignore');
            
            file(cellfun(@(x) isa(x,'missing'), file)) = {''};
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section B: extract example variable names & units
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            for i=1:size(file,2)
                examplebVarNames{1,i} = regexp(file{1,i},'^[a-zA-Z_0-9_|_@]+','once','match');
                examplebVarUnits{1,i} = regexp(file{1,i},'(?<=\[)[a-zA-Z_0-9_%]*(?=\])','once','match');
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section C: copy from example variable names & units
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            for k=1:size(obj.data,1)
                bVarNames = obj.data{k,6};
                for i=1:size(bVarNames,2)
                    j=find(strcmp(bVarNames{1,i},examplebVarNames));
                    
                    if isempty(j)
                        bVarUnits{1,i} = '';
                    else
                        bVarUnits{1,i} = examplebVarUnits{1,j};
                    end
                end
                obj.data{k,8} = bVarUnits;
            end
            
        end
        
        function export_FOCUS_MICROWAVE_FORMAT(obj, fileName, fileType)
            
            if (strcmp(fileType,"MDIF"))
                obj.exportMDIF_v1p0(fileName);
            elseif (strcmp(fileType,"LPCWAVE"))
                obj.exportLPCWAVE_v1p0(fileName);
            else
                disp('Unknown format!')
            end
        end
        
        %Read Data
        
        function [wave, successfulRead, message] = readPseudoWave_FOCUS_MICROWAVE_FORMAT(obj, propagationType, portNumber, frequencyIndex, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                wave = 0;
                successfulRead = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            if sum(strcmpi(propagationType,{'Incident','A'}))
                pt = 'A';
            elseif sum(strcmpi(propagationType,{'Reflected','B'}))
                pt = 'B';
            else
                wave = 0;
                successfulRead = 0;
                message = 'Error: Propagation type should be Incident or Reflected';
                return
            end
            
            if ((portNumber ~= 1) && (portNumber ~= 2))
                wave = 0;
                successfulRead = 0;
                message = 'Error: Port number should be 1 or 2';
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                wave = 0;
                successfulRead = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            bVarNameRe = [pt num2str(portNumber) 'reF' num2str(frequencyIndex-1)];
            bVarNameIm = [pt num2str(portNumber) 'imF' num2str(frequencyIndex-1)];
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarExists = (sum(strcmpi(bVarNameRe,bVarNames)) && sum(strcmpi(bVarNameIm,bVarNames)));
            
            if ~bVarExists
                wave = 0;
                successfulRead = 0;
                message = 'Error: wave data are not in the data block';
                return
                
            else
                bVarNameRe = bVarNames{1,find(strcmpi(bVarNameRe,bVarNames))};
                bVarNameIm = bVarNames{1,find(strcmpi(bVarNameIm,bVarNames))};
                
            end
            
            wave = blockTable{:,bVarNameRe} + 1i.*blockTable{:,bVarNameIm};
            successfulRead = 1;
            message = 'Successful read';
        end
        
        function [gamma, successfulRead, message] = readPointGamma_FOCUS_MICROWAVE_FORMAT(obj, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                gamma = 0;
                successfulRead = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            bVarNameMag = 'Gamma';
            bVarNamePhase = 'Phase';
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarExists = (sum(strcmpi(bVarNameMag,bVarNames)) && sum(strcmpi(bVarNamePhase,bVarNames)));
            
            if ~bVarExists
                gamma = 0;
                successfulRead = 0;
                message = 'Error: gamma data are not in the data block';
                return
                
            else
                bVarNameMag = bVarNames{1,find(strcmpi(bVarNameMag,bVarNames))};
                bVarUnitMag = bVarUnits{1,find(strcmpi(bVarNameMag,bVarNames))};
                
                bVarNamePhase = bVarNames{1,find(strcmpi(bVarNamePhase,bVarNames))};
                bVarUnitPhase = bVarUnits{1,find(strcmpi(bVarNamePhase,bVarNames))};
                
            end
            
            if strcmpi(bVarUnitMag, '')
                gammaMagValue = blockTable{:,bVarNameMag};
                
            elseif strcmpi(bVarUnitMag, 'dB')
                gammaMagValue = 10.^(blockTable{:,bVarNameMag}/20);
                
            else
                successfulRead = 0;
                message = 'Error: unknown gamma mag units';
                return
            end
            
            if sum(strcmpi(bVarUnitPhase, {'deg',''}))
                gammaPhaseValue = blockTable{:,bVarNamePhase}*pi/180;
                
            elseif sum(strcmpi(bVarUnitPhase, {'rad','rd','r'}))
                gammaPhaseValue = blockTable{:,bVarNamePhase};
                
            else
                successfulRead = 0;
                message = 'Error: unknown gamma phase units';
                return
            end
            
            gamma = gammaMagValue.*exp(gammaPhaseValue.*1i);
            successfulRead = 1;
            message = 'Successful read';
        end
        
        function [gamma, successfulRead, message] = readGamma_FOCUS_MICROWAVE_FORMAT(obj, gammaType, frequencyIndex, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                gamma = 0;
                successfulRead = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            if sum(strcmpi(gammaType,{'In','Input'}))
                gt = 'in';
            elseif sum(strcmpi(gammaType,{'L','Load'}))
                gt = 'L';
            elseif sum(strcmpi(gammaType,{'S','Source'}))
                gt = 'S';
            else
                gamma = 0;
                successfulRead = 0;
                message = 'Error: Gamma type should be in, source or load';
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                gamma = 0;
                successfulRead = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            bVarNameMag = ['|G' gt 'Waves@F' num2str(frequencyIndex-1) '|'];
            bVarNamePhase = ['Phi' gt 'Waves@F' num2str(frequencyIndex-1)];
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarExists = (sum(strcmpi(bVarNameMag,bVarNames)) && sum(strcmpi(bVarNamePhase,bVarNames)));
            
            if ~bVarExists
                gamma = 0;
                successfulRead = 0;
                message = 'Error: gamma data are not in the data block';
                return
                
            else
                bVarNameMag = bVarNames{1,find(strcmpi(bVarNameMag,bVarNames))};
                bVarUnitMag = bVarUnits{1,find(strcmpi(bVarNameMag,bVarNames))};
                
                bVarNamePhase = bVarNames{1,find(strcmpi(bVarNamePhase,bVarNames))};
                bVarUnitPhase = bVarUnits{1,find(strcmpi(bVarNamePhase,bVarNames))};
                
            end
            
            if strcmpi(bVarUnitMag, '')
                gammaMagValue = blockTable{:,bVarNameMag};
                
            elseif strcmpi(bVarUnitMag, 'dB')
                gammaMagValue = 10.^(blockTable{:,bVarNameMag}/20);
                
            else
                successfulRead = 0;
                message = 'Error: unknown gamma mag units';
                return
            end
            
            if sum(strcmpi(bVarUnitPhase, {'deg',''}))
                gammaPhaseValue = blockTable{:,bVarNamePhase}*pi/180;
                
            elseif sum(strcmpi(bVarUnitPhase, {'rad','rd','r'}))
                gammaPhaseValue = blockTable{:,bVarNamePhase};
                
            else
                successfulRead = 0;
                message = 'Error: unknown gamma phase units';
                return
            end
            
            gamma = gammaMagValue.*exp(gammaPhaseValue.*1i);
            successfulRead = 1;
            message = 'Successful read';
        end
        
        function [targetGamma, successfulRead, message] = readTargetGamma_FOCUS_MICROWAVE_FORMAT(obj, targetGammaType, frequencyIndex, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                targetGamma = 0;
                successfulRead = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            if sum(strcmpi(targetGammaType,{'L','Load'}))
                gt = 'L';
            elseif sum(strcmpi(targetGammaType,{'S','Source'}))
                gt = 'S';
            else
                targetGamma = 0;
                successfulRead = 0;
                message = 'Error: Gamma type should be in, source or load';
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                targetGamma = 0;
                successfulRead = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            bVarNameMag = ['Target|G' gt '@F' num2str(frequencyIndex-1) '|'];
            bVarNamePhase = ['TargetPhi' gt '@F' num2str(frequencyIndex-1)];
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarExists = (sum(strcmpi(bVarNameMag,bVarNames)) && sum(strcmpi(bVarNamePhase,bVarNames)));
            
            if ~bVarExists
                targetGamma = 0;
                successfulRead = 0;
                message = 'Error: gamma data are not in the data block';
                return
                
            else
                bVarNameMag = bVarNames{1,find(strcmpi(bVarNameMag,bVarNames))};
                bVarUnitMag = bVarUnits{1,find(strcmpi(bVarNameMag,bVarNames))};
                
                bVarNamePhase = bVarNames{1,find(strcmpi(bVarNamePhase,bVarNames))};
                bVarUnitPhase = bVarUnits{1,find(strcmpi(bVarNamePhase,bVarNames))};
                
            end
            
            if strcmpi(bVarUnitMag, '')
                gammaMagValue = blockTable{:,bVarNameMag};
                
            elseif strcmpi(bVarUnitMag, 'dB')
                gammaMagValue = 10.^(blockTable{:,bVarNameMag}/20);
                
            else
                successfulRead = 0;
                message = 'Error: unknown gamma mag units';
                return
            end
            
            if sum(strcmpi(bVarUnitPhase, {'deg',''}))
                gammaPhaseValue = blockTable{:,bVarNamePhase}*pi/180;
                
            elseif sum(strcmpi(bVarUnitPhase, {'rad','rd','r'}))
                gammaPhaseValue = blockTable{:,bVarNamePhase};
                
            else
                successfulRead = 0;
                message = 'Error: unknown gamma phase units';
                return
            end
            
            targetGamma = gammaMagValue.*exp(gammaPhaseValue.*1i);
            successfulRead = 1;
            message = 'Successful read';
        end
        
        function [power, successfulRead, message] = readPower_FOCUS_MICROWAVE_FORMAT(obj, powerType, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                power = 0;
                successfulRead = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            if sum(strcmpi(powerType,{'In','Input'}))
                pt = 'in';
            elseif sum(strcmpi(powerType,{'Out','Output'}))
                pt = 'out';
            else
                power = 0;
                successfulRead = 0;
                message = 'Error: Power type should be input or output';
                return
            end
            
            bVarNamePower = ['P' pt 'Waves'];
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarExists = sum(strcmpi(bVarNamePower,bVarNames));
            
            if ~bVarExists
                power = 0;
                successfulRead = 0;
                message = 'Error: power data are not in the data block';
                return
                
            else
                bVarNamePower = bVarNames{1,find(strcmpi(bVarNamePower,bVarNames))};
                bVarUnitPower = bVarUnits{1,find(strcmpi(bVarNamePower,bVarNames))};
                
            end
            
            power = blockTable{:,bVarNamePower};
            successfulRead = 1;
            message = ['Successful read. ' bVarNamePower ' units in ' bVarUnitPower];
        end
        
        function [gain, successfulRead, message] = readGain_FOCUS_MICROWAVE_FORMAT(obj, gainType, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                gain = 0;
                successfulRead = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            if sum(strcmpi(gainType,{'transducer','trd','td','t'}))
                gt = 'Trd';
            elseif sum(strcmpi(gainType,{'power','pwr','pw','p'}))
                gt = 'Pwr';
            else
                gain = 0;
                successfulRead = 0;
                message = 'Error: Gain type should be transducer or power';
                return
            end
            
            bVarNameGain = ['GainWaves' gt];
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarExists = sum(strcmpi(bVarNameGain,bVarNames));
            
            if ~bVarExists
                gain = 0;
                successfulRead = 0;
                message = 'Error: power data are not in the data block';
                return
                
            else
                bVarNameGain = bVarNames{1,find(strcmpi(bVarNameGain,bVarNames))};
                bVarUnitGain = bVarUnits{1,find(strcmpi(bVarNameGain,bVarNames))};
                
            end
            
            gain = blockTable{:,bVarNameGain};
            successfulRead = 1;
            message = ['Successful read. ' bVarNameGain ' units in ' bVarUnitGain];
        end
        
        function [dcBias, successfulRead, message] = readDCBias_FOCUS_MICROWAVE_FORMAT(obj, biasType, portNumber, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                dcBias = 0;
                successfulRead = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            if sum(strcmpi(biasType,{'voltage','volt','v'}))
                bt = 'V';
            elseif sum(strcmpi(biasType,{'current','curr','i'}))
                bt = 'I';
            else
                dcBias = 0;
                successfulRead = 0;
                message = 'Error: DC Bias type should be voltage or current';
                return
            end
            
            bVarNameDC = [bt num2str(portNumber)];
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarExists = sum(strcmpi(bVarNameDC,bVarNames));
            
            if ~bVarExists
                dcBias = 0;
                successfulRead = 0;
                message = 'Error: DC Bias data are not in the data block';
                return
                
            else
                bVarNameDC = bVarNames{1,find(strcmpi(bVarNameDC,bVarNames))};
                bVarUnitDC = bVarUnits{1,find(strcmpi(bVarNameDC,bVarNames))};
                
            end
            
            dcBias = blockTable{:,bVarNameDC};
            successfulRead = 1;
            message = ['Successful read. ' bVarNameDC ' units in ' bVarUnitDC];
        end
        
        function [efficiency, successfulRead, message] = readEfficiency_FOCUS_MICROWAVE_FORMAT(obj, efficiencyType, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                efficiency = 0;
                successfulRead = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarNameEff = '';
            if contains(efficiencyType,["de", "drain",...
                                        "drainefficiency", "drain_efficiency",...
                                        "drain-efficiency", "drain efficiency"],...
                                        'IgnoreCase',true)
                for i=1:size(bVarNames,2)
                    if contains(bVarNames{1,i},["de ", "de-", "de_", "drain",...
                                                "drainefficiency", "drain_efficiency",...
                                                "drain-efficiency", "drain efficiency"],...
                                                'IgnoreCase',true)
                         bVarNameEff = bVarNames{1,i};
                         break
                    end
                end
                
                if isempty(bVarNameEff)
                    efficiency = 0;
                    successfulRead = 0;
                    message = 'Error: Drain Efficiency not found in data block';
                    return
                end
                
            elseif contains(efficiencyType,["pae ", "pae-", "pae_", "power-added",...
                                        "power_added", "power added",...
                                        "power-added-efficiency", "power_added_efficiency", "power added efficiency"],...
                                        'IgnoreCase',true)
                for i=1:size(bVarNames,2)
                    if contains(bVarNames{1,i},["pae", "power-added",...
                                                "power_added", "power added",...
                                                "power-added-efficiency", "power_added_efficiency", "power added efficiency"],...
                                                'IgnoreCase',true)
                         bVarNameEff = bVarNames{1,i};
                         break
                    end
                end
                
                if isempty(bVarNameEff)
                    efficiency = 0;
                    successfulRead = 0;
                    message = 'Error: Power Added Efficiency not found in data block';
                    return
                end
                
            else
                efficiency = 0;
                successfulRead = 0;
                message = 'Error: Efficiency type should be drain or power-added';
                return
            end
            
            
            bVarUnitEff = bVarUnits{1,find(strcmpi(bVarNameEff,bVarNames))};
            
            efficiency = blockTable{:,bVarNameEff};
            successfulRead = 1;
            message = ['Successful read. ' bVarNameEff ' units in ' bVarUnitEff];
        end
        
        %Write Data
        
        function [successfulWrite, message] = writePseudoWave_FOCUS_MICROWAVE_FORMAT(obj, wave, propagationType, portNumber, frequencyIndex, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulWrite = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            if sum(strcmpi(propagationType,{'Incident','A'}))
                pt = 'A';
            elseif sum(strcmpi(propagationType,{'Reflected','B'}))
                pt = 'B';
            else
                successfulWrite = 0;
                message = 'Error: Propagation type should be Incident or Reflected';
                return
            end
            
            if ((portNumber ~= 1) && (portNumber ~= 2))
                successfulWrite = 0;
                message = 'Error: Port number should be 1 or 2';
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                successfulWrite = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            bVarNameRe = [pt num2str(portNumber) 'reF' num2str(frequencyIndex-1)];
            bVarNameIm = [pt num2str(portNumber) 'imF' num2str(frequencyIndex-1)];
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarExists = (sum(strcmpi(bVarNameRe,bVarNames)) && sum(strcmpi(bVarNameIm,bVarNames)));
            
            if ~bVarExists
                wave = 0;
                successfulWrite = 0;
                message = 'Error: wave data are not in the data block';
                return
                
            else
                bVarNameRe = bVarNames{1,find(strcmpi(bVarNameRe,bVarNames))};
                bVarNameIm = bVarNames{1,find(strcmpi(bVarNameIm,bVarNames))};
                
            end
            
            obj.data{blockNumber,1}{:,bVarNameRe} = real(wave);
            obj.data{blockNumber,1}{:,bVarNameIm} = imag(wave);
            successfulWrite = 1;
            message = 'Successful write';
        end
        
        function [successfulWrite, message] = writePointGamma_FOCUS_MICROWAVE_FORMAT(obj, gamma, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulWrite = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            bVarNameMag = 'Gamma';
            bVarNamePhase = 'Phase';
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarExists = (sum(strcmpi(bVarNameMag,bVarNames)) && sum(strcmpi(bVarNamePhase,bVarNames)));
            
            if ~bVarExists
                successfulWrite = 0;
                message = 'Error: gamma data are not in the data block';
                return
                
            else
                bVarNameMag = bVarNames{1,find(strcmpi(bVarNameMag,bVarNames))};
                bVarUnitMag = bVarUnits{1,find(strcmpi(bVarNameMag,bVarNames))};
                
                bVarNamePhase = bVarNames{1,find(strcmpi(bVarNamePhase,bVarNames))};
                bVarUnitPhase = bVarUnits{1,find(strcmpi(bVarNamePhase,bVarNames))};
                
            end
            
            if strcmpi(bVarUnitMag, '')
                gammaMagValue = abs(gamma);
                gammaMagUnit = '';
            elseif strcmpi(bVarUnitMag, 'dB')
                gammaMagValue = 20*log10(abs(gamma));
                gammaMagUnit = 'dB';
            else
                successfulWrite = 0;
                message = 'Error: unknown gamma mag units';
                return
            end
            
            if sum(strcmpi(bVarUnitPhase, {'deg',''}))
                gammaPhaseValue = unwrap(phase(gamma))*180/pi;
                gammaPhaseUnit = 'deg';
            elseif sum(strcmpi(bVarUnitPhase, {'rad','rd','r'}))
                gammaPhaseValue = unwrap(phase(gamma));
                gammaPhaseUnit = 'rad';
            else
                successfulWrite = 0;
                message = 'Error: unknown gamma phase units';
                return
            end
            
            obj.data{blockNumber,1}{:,bVarNameMag} = gammaMagValue;
            obj.data{blockNumber,8}{1,find(strcmpi(bVarNameMag,bVarNames))} = gammaMagUnit;
            
            obj.data{blockNumber,1}{:,bVarNamePhase} = gammaPhaseValue;
            obj.data{blockNumber,8}{1,find(strcmpi(bVarNamePhase,bVarNames))} = gammaPhaseUnit;
            
            if ~isempty(find(strcmp(obj.data{blockNumber,3},bVarNameMag)))
                obj.data{blockNumber,5}{1,find(strcmp(obj.data{blockNumber,3},bVarNameMag))} = gammaMagValue(1,1);
            end
            
            if ~isempty(find(strcmp(obj.data{blockNumber,3},bVarNamePhase)))
                obj.data{blockNumber,5}{1,find(strcmp(obj.data{blockNumber,3},bVarNamePhase))} = gammaPhaseValue(1,1);
            end
            
            successfulWrite = 1;
            message = 'Successful write';
        end
        
        function [successfulWrite, message] = writeGamma_FOCUS_MICROWAVE_FORMAT(obj, gamma, gammaType, frequencyIndex, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulWrite = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            if sum(strcmpi(gammaType,{'In','Input'}))
                gt = 'in';
            elseif sum(strcmpi(gammaType,{'L','Load'}))
                gt = 'L';
            elseif sum(strcmpi(gammaType,{'S','Source'}))
                gt = 'S';
            else
                successfulWrite = 0;
                message = 'Error: Gamma type should be in, source or load';
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                successfulWrite = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            bVarNameMag = ['|G' gt 'Waves@F' num2str(frequencyIndex-1) '|'];
            bVarNamePhase = ['Phi' gt 'Waves@F' num2str(frequencyIndex-1)];
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarExists = (sum(strcmpi(bVarNameMag,bVarNames)) && sum(strcmpi(bVarNamePhase,bVarNames)));
            
            if ~bVarExists
                successfulWrite = 0;
                message = 'Error: gamma data are not in the data block';
                return
                
            else
                bVarNameMag = bVarNames{1,find(strcmpi(bVarNameMag,bVarNames))};
                bVarUnitMag = bVarUnits{1,find(strcmpi(bVarNameMag,bVarNames))};
                
                bVarNamePhase = bVarNames{1,find(strcmpi(bVarNamePhase,bVarNames))};
                bVarUnitPhase = bVarUnits{1,find(strcmpi(bVarNamePhase,bVarNames))};
                
            end
            
            if strcmpi(bVarUnitMag, '')
                gammaMagValue = abs(gamma);
                gammaMagUnit = '';
            elseif strcmpi(bVarUnitMag, 'dB')
                gammaMagValue = 20*log10(abs(gamma));
                gammaMagUnit = 'dB';
            else
                successfulWrite = 0;
                message = 'Error: unknown gamma mag units';
                return
            end
            
            if sum(strcmpi(bVarUnitPhase, {'deg',''}))
                gammaPhaseValue = unwrap(phase(gamma))*180/pi;
                gammaPhaseUnit = 'deg';
            elseif sum(strcmpi(bVarUnitPhase, {'rad','rd','r'}))
                gammaPhaseValue = unwrap(phase(gamma));
                gammaPhaseUnit = 'rad';
            else
                successfulWrite = 0;
                message = 'Error: unknown gamma phase units';
                return
            end
            
            obj.data{blockNumber,1}{:,bVarNameMag} = gammaMagValue;
            obj.data{blockNumber,8}{1,find(strcmpi(bVarNameMag,bVarNames))} = gammaMagUnit;
            
            obj.data{blockNumber,1}{:,bVarNamePhase} = gammaPhaseValue;
            obj.data{blockNumber,8}{1,find(strcmpi(bVarNamePhase,bVarNames))} = gammaPhaseUnit;
            
            successfulWrite = 1;
            message = 'Successful write';
        end
        
        function [successfulWrite, message] = writeTargetGamma_FOCUS_MICROWAVE_FORMAT(obj, targetGamma, targetGammaType, frequencyIndex, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulWrite = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            if sum(strcmpi(targetGammaType,{'L','Load'}))
                gt = 'L';
            elseif sum(strcmpi(targetGammaType,{'S','Source'}))
                gt = 'S';
            else
                successfulWrite = 0;
                message = 'Error: Target gamma type should be source or load';
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                successfulWrite = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            bVarNameMag = ['Target|G' gt '@F' num2str(frequencyIndex-1) '|'];
            bVarNamePhase = ['TargetPhi' gt '@F' num2str(frequencyIndex-1)];
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarExists = (sum(strcmpi(bVarNameMag,bVarNames)) && sum(strcmpi(bVarNamePhase,bVarNames)));
            
            if ~bVarExists
                successfulWrite = 0;
                message = 'Error: target gamma data are not in the data block';
                return
                
            else
                bVarNameMag = bVarNames{1,find(strcmpi(bVarNameMag,bVarNames))};
                bVarUnitMag = bVarUnits{1,find(strcmpi(bVarNameMag,bVarNames))};
                
                bVarNamePhase = bVarNames{1,find(strcmpi(bVarNamePhase,bVarNames))};
                bVarUnitPhase = bVarUnits{1,find(strcmpi(bVarNamePhase,bVarNames))};
                
            end
            
            if strcmpi(bVarUnitMag, '')
                gammaMagValue = abs(targetGamma);
                gammaMagUnit = '';
            elseif strcmpi(bVarUnitMag, 'dB')
                gammaMagValue = 20*log10(abs(targetGamma));
                gammaMagUnit = 'dB';
            else
                successfulWrite = 0;
                message = 'Error: unknown gamma mag units';
                return
            end
            
            if sum(strcmpi(bVarUnitPhase, {'deg',''}))
                gammaPhaseValue = unwrap(phase(targetGamma))*180/pi;
                gammaPhaseUnit = 'deg';
            elseif sum(strcmpi(bVarUnitPhase, {'rad','rd','r'}))
                gammaPhaseValue = unwrap(phase(targetGamma));
                gammaPhaseUnit = 'rad';
            else
                successfulWrite = 0;
                message = 'Error: unknown gamma phase units';
                return
            end
            
            obj.data{blockNumber,1}{:,bVarNameMag} = gammaMagValue;
            obj.data{blockNumber,8}{1,find(strcmpi(bVarNameMag,bVarNames))} = gammaMagUnit;
            
            obj.data{blockNumber,1}{:,bVarNamePhase} = gammaPhaseValue;
            obj.data{blockNumber,8}{1,find(strcmpi(bVarNamePhase,bVarNames))} = gammaPhaseUnit;
            
            successfulWrite = 1;
            message = 'Successful write';
        end
        
        function [successfulWrite, message] = writePower_FOCUS_MICROWAVE_FORMAT(obj, power, powerType, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulWrite = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            if sum(strcmpi(powerType,{'In','Input'}))
                pt = 'in';
            elseif sum(strcmpi(powerType,{'Out','Output'}))
                pt = 'out';
            else
                successfulWrite = 0;
                message = 'Error: Power type should be input or output';
                return
            end
            
            bVarNamePower = ['P' pt 'Waves'];
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarExists = sum(strcmpi(bVarNamePower,bVarNames));
            
            if ~bVarExists
                successfulWrite = 0;
                message = 'Error: power data are not in the data block';
                return
                
            else
                bVarNamePower = bVarNames{1,find(strcmpi(bVarNamePower,bVarNames))};
                bVarUnitPower = bVarUnits{1,find(strcmpi(bVarNamePower,bVarNames))};
                
            end
            
            obj.data{blockNumber,1}{:,bVarNamePower} = power;
            successfulWrite = 1;
            message = ['Successful write. ' bVarNamePower ' units in ' bVarUnitPower];
        end
        
        function [successfulWrite, message] = writeGain_FOCUS_MICROWAVE_FORMAT(obj, gain, gainType, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulWrite = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            if sum(strcmpi(gainType,{'transducer','trd','td','t'}))
                gt = 'Trd';
            elseif sum(strcmpi(gainType,{'power','pwr','pw','p'}))
                gt = 'Pwr';
            else
                successfulWrite = 0;
                message = 'Error: Gain type should be transducer or power';
                return
            end
            
            bVarNameGain = ['GainWaves' gt];
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarExists = sum(strcmpi(bVarNameGain,bVarNames));
            
            if ~bVarExists
                successfulWrite = 0;
                message = 'Error: power data are not in the data block';
                return
                
            else
                bVarNameGain = bVarNames{1,find(strcmpi(bVarNameGain,bVarNames))};
                bVarUnitGain = bVarUnits{1,find(strcmpi(bVarNameGain,bVarNames))};
                
            end
            
            obj.data{blockNumber,1}{:,bVarNameGain} = gain;
            successfulWrite = 1;
            message = ['Successful write. ' bVarNameGain ' units in ' bVarUnitGain];
        end
        
        function [successfulWrite, message] = writeDCBias_FOCUS_MICROWAVE_FORMAT(obj, dcBias, biasType, portNumber, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulWrite = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            
            if sum(strcmpi(biasType,{'voltage','volt','v'}))
                bt = 'V';
            elseif sum(strcmpi(biasType,{'current','curr','i'}))
                bt = 'I';
            else
                successfulWrite = 0;
                message = 'Error: DC Bias type should be voltage or current';
                return
            end
            
            bVarNameDC = [bt num2str(portNumber)];
            
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarExists = sum(strcmpi(bVarNameDC,bVarNames));
            
            if ~bVarExists
                successfulWrite = 0;
                message = 'Error: DC Bias data are not in the data block';
                return
                
            else
                bVarNameDC = bVarNames{1,find(strcmpi(bVarNameDC,bVarNames))};
                bVarUnitDC = bVarUnits{1,find(strcmpi(bVarNameDC,bVarNames))};
                
            end
            
            obj.data{blockNumber,1}{:,bVarNameDC} = dcBias;
            successfulWrite = 1;
            message = ['Successful write. ' bVarNameDC ' units in ' bVarUnitDC];
        end
        
        function [successfulWrite, message] = writeEfficiency_FOCUS_MICROWAVE_FORMAT(obj, efficiency, efficiencyType, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulWrite = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            blockTable = obj.data{blockNumber,1};
            bVarNames = blockTable.Properties.VariableNames;
            bVarUnits = obj.data{blockNumber,8};
            
            bVarNameEff = '';
            if contains(efficiencyType,["de", "drain",...
                                        "drainefficiency", "drain_efficiency",...
                                        "drain-efficiency", "drain efficiency"],...
                                        'IgnoreCase',true)
                for i=1:size(bVarNames,2)
                    if contains(bVarNames{1,i},["de ", "de-", "de_", "drain",...
                                                "drainefficiency", "drain_efficiency",...
                                                "drain-efficiency", "drain efficiency"],...
                                                'IgnoreCase',true)
                         bVarNameEff = bVarNames{1,i};
                         break
                    end
                end
                
                if isempty(bVarNameEff)
                    successfulWrite = 0;
                    message = 'Error: Drain Efficiency not found in data block';
                    return
                end
                
            elseif contains(efficiencyType,["pae ", "pae-", "pae_", "power-added",...
                                        "power_added", "power added",...
                                        "power-added-efficiency", "power_added_efficiency", "power added efficiency"],...
                                        'IgnoreCase',true)
                for i=1:size(bVarNames,2)
                    if contains(bVarNames{1,i},["pae", "power-added",...
                                                "power_added", "power added",...
                                                "power-added-efficiency", "power_added_efficiency", "power added efficiency"],...
                                                'IgnoreCase',true)
                         bVarNameEff = bVarNames{1,i};
                         break
                    end
                end
                
                if isempty(bVarNameEff)
                    successfulWrite = 0;
                    message = 'Error: Power Added Efficiency not found in data block';
                    return
                end
                
            else
                successfulWrite = 0;
                message = 'Error: Efficiency type should be drain or power-added';
                return
            end
            
            
            bVarUnitEff = bVarUnits{1,find(strcmpi(bVarNameEff,bVarNames))};
            
            obj.data{blockNumber,1}{:,bVarNameEff} = efficiency;
            successfulWrite = 1;
            message = ['Successful read. ' bVarNameEff ' units in ' bVarUnitEff];
        end
        
        %Calculate Data from A/B Pseudo Waves and DC Bias
        
        function [power, successfulCalculation, message] = calculatePowerAtFreq_FOCUS_MICROWAVE_FORMAT(obj, powerType, frequencyIndex, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulCalculation = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                successfulWrite = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            if sum(strcmpi(powerType,{'In','Input'}))
                
                [power, successfulCalculation, message] = obj.calculatePowerInDelAtFreqFromABWaves_v1p0(obj.inputPortNumber, frequencyIndex, blockNumber);
                return
            elseif sum(strcmpi(powerType,{'Available In','Available-In','Available_In',...
                                          'Available Input','Available-Input','Available_Input',...
                                          'Available Source','Available-Source','Available_Source', 'Avs'}))
                
                [power, successfulCalculation, message] = obj.calculatePowerAvsAtFreqFromABWaves_v1p0(obj.inputPortNumber, frequencyIndex, blockNumber);
                return
                
            elseif sum(strcmpi(powerType,{'Out','Output','Del', 'Delivered'}))
                
                [power, successfulCalculation, message] = obj.calculatePowerOutDelAtFreqFromABWaves_v1p0(obj.outputPortNumber, frequencyIndex, blockNumber);
                return
                
            else
                successfulCalculation = 0;
                message = 'Error: Power type should be input, output or available-input';
                power = 0;
                return
                
            end
            
        end
        
        function [power, successfulCalculation, message] = calculatePower_FOCUS_MICROWAVE_FORMAT(obj, powerType, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulCalculation = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            if sum(strcmpi(powerType,{'InDel','InputDelivered'}))
                
                power = 0;
                for frequencyIndex=1:max(size(obj.Freq))
                    [powerHarm, successfulCalculation, message] = obj.calculatePowerInDelAtFreqFromABWaves_v1p0(obj.inputPortNumber, frequencyIndex, blockNumber);
                    
                    if ~successfulCalculation
                        return
                    end
                    
                    power = power+powerHarm;
                end
                
                return
            elseif sum(strcmpi(powerType,{'In', 'Input', 'Available In','Available-In','Available_In',...
                                          'Available Input','Available-Input','Available_Input',...
                                          'Available Source','Available-Source','Available_Source', 'Avs'}))
                
                power = 0;
                for frequencyIndex=1:max(size(obj.Freq))
                    [powerHarm, successfulCalculation, message] = obj.calculatePowerAvsAtFreqFromABWaves_v1p0(obj.inputPortNumber, frequencyIndex, blockNumber);
                    
                    if ~successfulCalculation
                        return
                    end
                    
                    power = power+powerHarm;
                end
                
                return
                
            elseif sum(strcmpi(powerType,{'Out','Output','Del', 'Delivered'}))
                
                power = 0;
                for frequencyIndex=1:max(size(obj.Freq))
                    [powerHarm, successfulCalculation, message] = obj.calculatePowerOutDelAtFreqFromABWaves_v1p0(obj.outputPortNumber, frequencyIndex, blockNumber);
                    
                    if ~successfulCalculation
                        return
                    end
                    
                    power = power+powerHarm;
                end
                
                return
                
            else
                successfulCalculation = 0;
                message = 'Error: Power type should be input, output or available-input';
                powerHarm = 0;
                return
                
            end
            
        end
        
        function [gain, successfulCalculation, message] = calculateGain_FOCUS_MICROWAVE_FORMAT(obj, gainType, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                gain = 0;
                successfulCalculation = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            if sum(strcmpi(gainType,{'transducer','trd','td','t'}))
                [powerIn, successfulCalculation, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('in', blockNumber);
                if ~successfulCalculation
                    gain = 0;
                    return
                end
                
                [powerOut, successfulCalculation, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('out', blockNumber);
                if ~successfulCalculation
                    gain = 0;
                    return
                end
                
                gain = 10*log10(abs(powerOut./powerIn));
                
            elseif sum(strcmpi(gainType,{'power','pwr','pw','p'}))
                [powerInDel, successfulCalculation, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('indel', blockNumber);
                if ~successfulCalculation
                    gain = 0;
                    return
                end
                
                [powerOut, successfulCalculation, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('out', blockNumber);
                if ~successfulCalculation
                    gain = 0;
                    return
                end
                
                gain = 10*log10(abs(powerOut./powerInDel));
                
            else
                gain = 0;
                successfulCalculation = 0;
                message = 'Error: Gain type should be transducer or power';
                return
            end
            
            successfulCalculation = 1;
            message = ['Successful read. Gain units in dB'];
            
        end
        
        function [efficiency, successfulCalculation, message] = calculateEfficiency_FOCUS_MICROWAVE_FORMAT(obj, efficiencyType, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                efficiency = 0;
                successfulCalculation = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            if contains(efficiencyType,["de", "drain",...
                                        "drainefficiency", "drain_efficiency",...
                                        "drain-efficiency", "drain efficiency"],...
                                        'IgnoreCase',true)
                [VDD, successfulCalculation, message] = obj.readDCBias_FOCUS_MICROWAVE_FORMAT('V', obj.outputPortNumber, blockNumber);
                if ~successfulCalculation
                    efficiency = 0;
                    return
                end
                
                [IDD, successfulCalculation, message] = obj.readDCBias_FOCUS_MICROWAVE_FORMAT('I', obj.outputPortNumber, blockNumber);
                if ~successfulCalculation
                    efficiency = 0;
                    return
                end
                
                splitMessage = split(message);
                unitsMessage = splitMessage{max(size(splitMessage)),1};
                
                if contains(unitsMessage,"mA",'IgnoreCase',true)
                    IDD = IDD/1000;
                end
                
                powerDC = VDD.*IDD;
                
                [powerOut, successfulCalculation, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('out', blockNumber);
                if ~successfulCalculation
                    efficiency = 0;
                    return
                end
                
                efficiency = abs(powerOut)./powerDC*100;
                
            elseif contains(efficiencyType,["pae ", "pae-", "pae_", "power-added",...
                                        "power_added", "power added",...
                                        "power-added-efficiency", "power_added_efficiency", "power added efficiency"],...
                                        'IgnoreCase',true)
                
                [VDD, successfulCalculation, message] = obj.readDCBias_FOCUS_MICROWAVE_FORMAT('V', obj.outputPortNumber, blockNumber);
                if ~successfulCalculation
                    efficiency = 0;
                    return
                end
                
                [IDD, successfulCalculation, message] = obj.readDCBias_FOCUS_MICROWAVE_FORMAT('I', obj.outputPortNumber, blockNumber);
                if ~successfulCalculation
                    efficiency = 0;
                    return
                end
                
                powerDC = VDD.*IDD;
                
                [powerIn, successfulCalculation, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('in', blockNumber);
                if ~successfulCalculation
                    gain = 0;
                    return
                end
                
                [powerOut, successfulCalculation, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('out', blockNumber);
                if ~successfulCalculation
                    gain = 0;
                    return
                end
                
                efficiency = abs(powerOut-powerIn)./powerDC*100;
                
            else
                efficiency = 0;
                successfulCalculation = 0;
                message = 'Error: Efficiency type should be drain or power-added';
                return
            end
            
            successfulCalculation = 1;
            message = ['Successful calculation. Efficiency units in %'];
        end
        
        function [efficiency, successfulCalculation, message] = calculateEfficiency_AmbiguousEfficiencyDefinition_FOCUS_MICROWAVE_FORMAT(obj, efficiencyType, dcPortList, powerAdded, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                efficiency = 0;
                successfulCalculation = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            if contains(efficiencyType,["de", "drain",...
                                        "drainefficiency", "drain_efficiency",...
                                        "drain-efficiency", "drain efficiency"],...
                                        'IgnoreCase',true)
                [VDD, successfulCalculation, message] = obj.readDCBias_FOCUS_MICROWAVE_FORMAT('V', obj.outputPortNumber, blockNumber);
                if ~successfulCalculation
                    efficiency = 0;
                    return
                end
                
                [IDD, successfulCalculation, message] = obj.readDCBias_FOCUS_MICROWAVE_FORMAT('I', obj.outputPortNumber, blockNumber);
                if ~successfulCalculation
                    efficiency = 0;
                    return
                end
                
                splitMessage = split(message);
                unitsMessage = splitMessage{max(size(splitMessage)),1};
                
                if contains(unitsMessage,"mA",'IgnoreCase',true)
                    IDD = IDD/1000;
                end
                
                powerDC = VDD.*IDD;
                
                [powerOut, successfulCalculation, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('out', blockNumber);
                if ~successfulCalculation
                    efficiency = 0;
                    return
                end
                
                efficiency = abs(powerOut)./powerDC*100;
                
            elseif contains(efficiencyType,["pae ", "pae-", "pae_", "power-added",...
                                        "power_added", "power added",...
                                        "power-added-efficiency", "power_added_efficiency", "power added efficiency"],...
                                        'IgnoreCase',true)
                
                [VDD, successfulCalculation, message] = obj.readDCBias_FOCUS_MICROWAVE_FORMAT('V', obj.outputPortNumber, blockNumber);
                if ~successfulCalculation
                    efficiency = 0;
                    return
                end
                
                [IDD, successfulCalculation, message] = obj.readDCBias_FOCUS_MICROWAVE_FORMAT('I', obj.outputPortNumber, blockNumber);
                if ~successfulCalculation
                    efficiency = 0;
                    return
                end
                
                powerDC = VDD.*IDD;
                
                [powerIn, successfulCalculation, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('in', blockNumber);
                if ~successfulCalculation
                    gain = 0;
                    return
                end
                
                [powerOut, successfulCalculation, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('out', blockNumber);
                if ~successfulCalculation
                    gain = 0;
                    return
                end
                
                efficiency = abs(powerOut-powerIn)./powerDC*100;
                
            else
                efficiency = 0;
                successfulCalculation = 0;
                message = 'Error: Efficiency type should be drain or power-added';
                return
            end
            
            successfulCalculation = 1;
            message = ['Successful calculation. Efficiency units in %'];
        end
        
        function [gamma, successfulCalculation, message] = calculateGamma_FOCUS_MICROWAVE_FORMAT(obj, gammaType, frequencyIndex, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                gamma = 0;
                successfulCalculation = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                successfulCalculation = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            if sum(strcmpi(gammaType,{'L','Load'}))
                [A2F0, successfulCalculation, message] = obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('incident', obj.outputPortNumber, frequencyIndex, blockNumber);
                if ~successfulCalculation
                    gamma = 0;
                    return
                end
                
                [B2F0, successfulCalculation, message] = obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('reflected', obj.outputPortNumber, frequencyIndex, blockNumber);
                if ~successfulCalculation
                    gamma = 0;
                    return
                end
                
                gamma = A2F0./B2F0;
                successfulCalculation = 1;
                message = ['Successful calculation.'];
                
            elseif sum(strcmpi(gammaType,{'In','Input'}))
                [A1F0, successfulCalculation, message] = obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('incident', obj.inputPortNumber, frequencyIndex, blockNumber);
                if ~successfulCalculation
                    gamma = 0;
                    return
                end
                
                [B1F0, successfulCalculation, message] = obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('reflected', obj.inputPortNumber, frequencyIndex, blockNumber);
                if ~successfulCalculation
                    gamma = 0;
                    return
                end
                
                gamma = B1F0./A1F0;
                successfulCalculation = 1;
                message = ['Successful calculation.'];
                
            else
                successfulCalculation = 0;
                message = 'Error: Unknown gamma type';
                return
                
            end
        end
        
        %De-embed data
        
        function [successfulDeembedding, message] = deembed_FOCUS_MICROWAVE_FORMAT(obj, inputFixtureFileName, outputFixtureFileName)
            for blockNumber = 1:size(obj.data,1)
                
                for frequencyIndex = 1:max(size(obj.Freq))
                    
                    %De-embedding A/B waves and target source/load gamma
                    [successfulDeembedding, message] = obj.deembedABWaves_v1p0(inputFixtureFileName, outputFixtureFileName, frequencyIndex, blockNumber);
                    if ~successfulDeembedding
                        return
                    end
                    
                    %Writing calculated load gamma
                    [gammaL, successfulDeembedding, message] = obj.calculateGamma_FOCUS_MICROWAVE_FORMAT('load', frequencyIndex, blockNumber);
                    if ~successfulDeembedding
                        return
                    end
                    [successfulDeembedding, message] = obj.writeGamma_FOCUS_MICROWAVE_FORMAT(gammaL, 'load', frequencyIndex, blockNumber);
                    if ~successfulDeembedding
                        return
                    end
                    
                    %Writing calculated input gamma
                    [gammaIn, successfulDeembedding, message] = obj.calculateGamma_FOCUS_MICROWAVE_FORMAT('input', frequencyIndex, blockNumber);
                    if ~successfulDeembedding
                        return
                    end
                    [successfulDeembedding, message] = obj.writeGamma_FOCUS_MICROWAVE_FORMAT(gammaIn, 'input', frequencyIndex, blockNumber);
                    if ~successfulDeembedding
                        return
                    end
                    
                    
                end
                
                %Writing calculated input power
                [power, successfulDeembedding, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('input', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                bVarUnitPower = obj.data{blockNumber,8}{1,find(strcmpi('PinWaves',obj.data{1,6}))};
                if strcmpi(bVarUnitPower, 'dBm')
                    power = 10*log10(abs(power))+30;
                end
                
                [successfulDeembedding, message] = obj.writePower_FOCUS_MICROWAVE_FORMAT(power, 'input', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                %Writing calculated output power
                [power, successfulDeembedding, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('output', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                bVarUnitPower = obj.data{blockNumber,8}{1,find(strcmpi('PoutWaves',obj.data{1,6}))};
                if strcmpi(bVarUnitPower, 'dBm')
                    power = 10*log10(abs(power))+30;
                end
                
                [successfulDeembedding, message] = obj.writePower_FOCUS_MICROWAVE_FORMAT(power, 'output', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                %Writing calculated transducer gain
                [gain, successfulDeembedding, message] = obj.calculateGain_FOCUS_MICROWAVE_FORMAT('transducer', blockNumber);
                if ~successfulDeembedding
                    return
                end
                [successfulDeembedding, message] = obj.writeGain_FOCUS_MICROWAVE_FORMAT(gain, 'transducer', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                %Writing calculated power gain
                [gain, successfulDeembedding, message] = obj.calculateGain_FOCUS_MICROWAVE_FORMAT('power', blockNumber);
                if ~successfulDeembedding
                    return
                end
                [successfulDeembedding, message] = obj.writeGain_FOCUS_MICROWAVE_FORMAT(gain, 'power', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                %Writing calculated drain efficiency
                [efficiency, successfulDeembedding, message] = obj.calculateEfficiency_FOCUS_MICROWAVE_FORMAT('drain', blockNumber);
                if ~successfulDeembedding
                    return
                end
                [successfulDeembedding, message] = writeEfficiency_FOCUS_MICROWAVE_FORMAT(obj, efficiency, 'drain', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                if ~isempty(obj.pullType)
                    if(obj.pullType(1) == 'I')
                        [successfulDeembedding, message] = obj.deembedPointGamma_v1p0('source', inputFixtureFileName, str2num(obj.pullType(2)), blockNumber);
                        if ~successfulDeembedding
                            return
                        end
                        
                    elseif(obj.pullType(1) == 'O')
                        [successfulDeembedding, message] = obj.deembedPointGamma_v1p0('load', outputFixtureFileName, str2num(obj.pullType(2)), blockNumber);
                        if ~successfulDeembedding
                            return
                        end
                        
                    end
                end
                
            end
            
            successfulDeembedding = 1;
            message = 'Successful deembedding';
        end
        
        function [successfulDeembedding, message] = deembed_AmbiguousEfficiencyDefinition_FOCUS_MICROWAVE_FORMAT(obj, dcPortList, powerAdded, inputFixtureFileName, outputFixtureFileName)
            for blockNumber = 1:size(obj.data,1)
                
                for frequencyIndex = 1:max(size(obj.Freq))
                    
                    %De-embedding A/B waves and target source/load gamma
                    [successfulDeembedding, message] = obj.deembedABWaves_v1p0(inputFixtureFileName, outputFixtureFileName, frequencyIndex, blockNumber);
                    if ~successfulDeembedding
                        return
                    end
                    
                    %Writing calculated load gamma
                    [gammaL, successfulDeembedding, message] = obj.calculateGamma_FOCUS_MICROWAVE_FORMAT('load', frequencyIndex, blockNumber);
                    if ~successfulDeembedding
                        return
                    end
                    [successfulDeembedding, message] = obj.writeGamma_FOCUS_MICROWAVE_FORMAT(gammaL, 'load', frequencyIndex, blockNumber);
                    if ~successfulDeembedding
                        return
                    end
                    
                    %Writing calculated input gamma
                    [gammaIn, successfulDeembedding, message] = obj.calculateGamma_FOCUS_MICROWAVE_FORMAT('input', frequencyIndex, blockNumber);
                    if ~successfulDeembedding
                        return
                    end
                    [successfulDeembedding, message] = obj.writeGamma_FOCUS_MICROWAVE_FORMAT(gammaIn, 'input', frequencyIndex, blockNumber);
                    if ~successfulDeembedding
                        return
                    end
                    
                    
                end
                
                %Writing calculated input power
                [power, successfulDeembedding, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('input', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                bVarUnitPower = obj.data{blockNumber,8}{1,find(strcmpi('PinWaves',obj.data{1,6}))};
                if strcmpi(bVarUnitPower, 'dBm')
                    power = 10*log10(abs(power))+30;
                end
                
                [successfulDeembedding, message] = obj.writePower_FOCUS_MICROWAVE_FORMAT(power, 'input', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                %Writing calculated output power
                [power, successfulDeembedding, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('output', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                bVarUnitPower = obj.data{blockNumber,8}{1,find(strcmpi('PoutWaves',obj.data{1,6}))};
                if strcmpi(bVarUnitPower, 'dBm')
                    power = 10*log10(abs(power))+30;
                end
                
                [successfulDeembedding, message] = obj.writePower_FOCUS_MICROWAVE_FORMAT(power, 'output', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                %Writing calculated transducer gain
                [gain, successfulDeembedding, message] = obj.calculateGain_FOCUS_MICROWAVE_FORMAT('transducer', blockNumber);
                if ~successfulDeembedding
                    return
                end
                [successfulDeembedding, message] = obj.writeGain_FOCUS_MICROWAVE_FORMAT(gain, 'transducer', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                %Writing calculated power gain
                [gain, successfulDeembedding, message] = obj.calculateGain_FOCUS_MICROWAVE_FORMAT('power', blockNumber);
                if ~successfulDeembedding
                    return
                end
                [successfulDeembedding, message] = obj.writeGain_FOCUS_MICROWAVE_FORMAT(gain, 'power', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                %Writing calculated drain efficiency
                [efficiency, successfulDeembedding, message] = obj.calculateEfficiency_FOCUS_MICROWAVE_FORMAT('drain', blockNumber);
                if ~successfulDeembedding
                    return
                end
                [successfulDeembedding, message] = writeEfficiency_FOCUS_MICROWAVE_FORMAT(obj, efficiency, 'drain', blockNumber);
                if ~successfulDeembedding
                    return
                end
                
                if ~isempty(obj.pullType)
                    if(obj.pullType(1) == 'I')
                        [successfulDeembedding, message] = obj.deembedPointGamma_v1p0('source', inputFixtureFileName, str2num(obj.pullType(2)), blockNumber);
                        if ~successfulDeembedding
                            return
                        end
                        
                    elseif(obj.pullType(1) == 'O')
                        [successfulDeembedding, message] = obj.deembedPointGamma_v1p0('load', outputFixtureFileName, str2num(obj.pullType(2)), blockNumber);
                        if ~successfulDeembedding
                            return
                        end
                        
                    end
                end
                
            end
            
            successfulDeembedding = 1;
            message = 'Successful deembedding';
        end
        
        %Embed data
        
        function [successfulEmbedding, message] = embed_FOCUS_MICROWAVE_FORMAT(obj, inputFixtureFileName, outputFixtureFileName)
            for blockNumber = 1:size(obj.data,1)
                
                for frequencyIndex = 1:max(size(obj.Freq))
                    
                    %Embedding A/B waves and target source/load gamma
                    [successfulEmbedding, message] = obj.embedABWaves_v1p0(inputFixtureFileName, outputFixtureFileName, frequencyIndex, blockNumber);
                    if ~successfulEmbedding
                        return
                    end
                    
                    %Writing calculated load gamma
                    [gammaL, successfulEmbedding, message] = obj.calculateGamma_FOCUS_MICROWAVE_FORMAT('load', frequencyIndex, blockNumber);
                    if ~successfulEmbedding
                        return
                    end
                    [successfulEmbedding, message] = obj.writeGamma_FOCUS_MICROWAVE_FORMAT(gammaL, 'load', frequencyIndex, blockNumber);
                    if ~successfulEmbedding
                        return
                    end
                    
                    %Writing calculated input gamma
                    [gammaIn, successfulEmbedding, message] = obj.calculateGamma_FOCUS_MICROWAVE_FORMAT('input', frequencyIndex, blockNumber);
                    if ~successfulEmbedding
                        return
                    end
                    [successfulEmbedding, message] = obj.writeGamma_FOCUS_MICROWAVE_FORMAT(gammaIn, 'input', frequencyIndex, blockNumber);
                    if ~successfulEmbedding
                        return
                    end
                    
                    
                end
                
                %Writing calculated input power
                [power, successfulEmbedding, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('input', blockNumber);
                if ~successfulEmbedding
                    return
                end
                
                bVarUnitPower = obj.data{blockNumber,8}{1,find(strcmpi('PinWaves',obj.data{1,6}))};
                if strcmpi(bVarUnitPower, 'dBm')
                    power = 10*log10(power)+30;
                end
                
                [successfulEmbedding, message] = obj.writePower_FOCUS_MICROWAVE_FORMAT(power, 'input', blockNumber);
                if ~successfulEmbedding
                    return
                end
                
                %Writing calculated output power
                [power, successfulEmbedding, message] = obj.calculatePower_FOCUS_MICROWAVE_FORMAT('output', blockNumber);
                if ~successfulEmbedding
                    return
                end
                
                bVarUnitPower = obj.data{blockNumber,8}{1,find(strcmpi('PoutWaves',obj.data{1,6}))};
                if strcmpi(bVarUnitPower, 'dBm')
                    power = 10*log10(power)+30;
                end
                
                [successfulEmbedding, message] = obj.writePower_FOCUS_MICROWAVE_FORMAT(power, 'output', blockNumber);
                if ~successfulEmbedding
                    return
                end
                
                %Writing calculated transducer gain
                [gain, successfulEmbedding, message] = obj.calculateGain_FOCUS_MICROWAVE_FORMAT('transducer', blockNumber);
                if ~successfulEmbedding
                    return
                end
                [successfulEmbedding, message] = obj.writeGain_FOCUS_MICROWAVE_FORMAT(gain, 'transducer', blockNumber);
                if ~successfulEmbedding
                    return
                end
                
                %Writing calculated power gain
                [gain, successfulEmbedding, message] = obj.calculateGain_FOCUS_MICROWAVE_FORMAT('power', blockNumber);
                if ~successfulEmbedding
                    return
                end
                [successfulEmbedding, message] = obj.writeGain_FOCUS_MICROWAVE_FORMAT(gain, 'power', blockNumber);
                if ~successfulEmbedding
                    return
                end
                
                %Writing calculated drain efficiency
                [efficiency, successfulEmbedding, message] = obj.calculateEfficiency_FOCUS_MICROWAVE_FORMAT('drain', blockNumber);
                if ~successfulEmbedding
                    return
                end
                [successfulEmbedding, message] = writeEfficiency_FOCUS_MICROWAVE_FORMAT(obj, efficiency, 'drain', blockNumber);
                if ~successfulEmbedding
                    return
                end
                
                if ~isempty(obj.pullType)
                    if(obj.pullType(1) == 'I')
                        [successfulEmbedding, message] = obj.embedPointGamma_v1p0('source', inputFixtureFileName, str2num(obj.pullType(2)), blockNumber);
                        if ~successfulEmbedding
                            return
                        end
                        
                    elseif(obj.pullType(1) == 'O')
                        [successfulEmbedding, message] = obj.embedPointGamma_v1p0('load', outputFixtureFileName, str2num(obj.pullType(2)), blockNumber);
                        if ~successfulEmbedding
                            return
                        end
                        
                    end
                end
                
            end
            
            successfulEmbedding = 1;
            message = 'Successful deembedding';
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% ANTEVERTA TOOLS
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    end
    
    methods (Access = private)
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% FOCUS MICROWAVE TOOLS
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %File Importers
        
        function [data, dataFormat] = importMDIF_v1p0(obj, fileName)
            %% MDIF File Importer v1.0
            %Description:
            %  MDIF is a universal file type suitable for importing in ADS
            %  In this format the data/measurements are organized in 'blocks'. There are
            %  'external/outer' variables which are used to sweep between blocks and
            %  'block' variables which are used to organize the data values in columns
            %  inside the block.
            %  
            %  In general these variables have a 'type' which is an integer.
            %  Typical variable types are:
            %  0 -> integer
            %  1 -> real(floating)
            %  2 -> string
            %
            %  Only block variables can also have additional types:
            %  3 -> complex
            %  4 -> boolean
            %  5 -> binary
            %  6 -> octal
            %  7 -> hexadecimal
            %  8 -> byte16
            %
            %Disclaimer:
            %  This script is fairly generic but still is not suitable for the most
            %  generic format of MDIF files.
            %
            %  This script can be used to load any generic MDIF with the condition that
            %  the block variables are formatted in a single line. Multi-line general
            %  formats are not supported by this script.
            %
            %Responsible person: Ioannis Peppas
            %Contact: Ioannis.Peppas-EE@infineon.com
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section A: import mdf file
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            file=readcell(fileName,'FileType','text', ...
                'CommentStyle','!', ...
                'Delimiter',{'\t',' ','%%'}, ...
                'ConsecutiveDelimitersRule','join', ...
                'LeadingDelimitersRule','ignore'); %'file' is a cell matrix
            
            file(cellfun(@(x) isa(x,'missing'), file)) = {char('')};
            file=rmmissing(cell2table(file),2);% remove empty cells
            file=table2cell(file);
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section B: convert file into universal 'data' format
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            blockIndex=0;
            varIndex=0;
            
            for i=1:size(file,1)
                if (strcmp(file{i,1},'VAR'))
                    % reading 'external' variables
                    varIndex=varIndex+1;
                    varNames{1,varIndex}  = regexp(file{i,2},'^[a-zA-Z_0-9_|_@]+','once','match');
                    varTypes{1,varIndex}  = str2num(regexp(file{i,2},'(?<=\()[^)]*(?=\))','once','match'));
                    varValues{1,varIndex} = file{i,4};
                    
                elseif (strcmp(file{i,1},'BEGIN'))
                    % this is the start of the block
                    blockIndex=blockIndex+1;
                    iBlockBegin=i;
                    blockName{1,1} = file{i,2};
                    
                elseif (strcmp(file{i,1},'END'))
                    % this is the end of the block
                    varIndex=0;
                    iBlockEnd=i;
                    
                    % reading 'block' variables
                    for j=1:size(file,2)
                        bVarNames{1,j} = regexp(file{iBlockBegin+1,j},'^[a-zA-Z_0-9_|_@]+','once','match');
                        bVarTypes{1,j} = regexp(file{iBlockBegin+1,j},'(?<=\()[^)]*(?=\))','once','match');
                        bVarUnits{1,j} = '';
                    end
                    
                    % reading block
                    block=table2array(cell2table(file((iBlockBegin+2):(iBlockEnd-1),:)));
                    blockTable=array2table(block,'VariableNames',bVarNames);
                    
                    % creating 'data' format
                    dataFormat = {'blockTable','blockName','varNames','varTypes','varValues','bVarNames','bVarTypes','bVarUnits'};
                    data(blockIndex,:)={blockTable,blockName,varNames,varTypes,varValues,bVarNames,bVarTypes,bVarUnits};
                    
                end
            end
        end
        
        function [data, dataFormat] = importLPCWAVE_v1p0(obj, fileName)
            %% LPCwave File Importer v1.0
            %Description:
            %  LPCwave is a Focus Microwave loadpull data format
            %  In this format the data/measurements are organized in 'blocks'. There are
            %  'external/outer' variables which are used to sweep between blocks and
            %  'block' variables which are used to organize the data values in columns
            %  inside the block.
            %  In general these variables are ALWAYS integer/real
            %  
            %  The general format seems to be:
            %  
            %  !Comments
            %  !------------------------------------------------------------- ... -------------------
            %  Point Gamma Phase[deg] bVar1Name[var1Unit] bVar2Name[var1Unit] ... bVarNName[varNUnit]
            %  !------------------------------------------------------------- ... -------------------
            %  # 001 gammaValue phaseValue
            %  bVar1Value1 bVar2Value1 ... bVarNValue1
            %  bVar1Value2 bVar2Value2 ... bVarNValue2
            %       :           :      ...      :
            %       :           :      ...      :
            %  bVar1ValueM bVar2ValueM ... bVarNValueM
            %  # 002 gammaValue phaseValue
            %  bVar1Value1 bVar2Value1 ... bVarNValue1
            %  bVar1Value2 bVar2Value2 ... bVarNValue2
            %       :           :      ...      :
            %       :           :      ...      :
            %  bVar1ValueM bVar2ValueM ... bVarNValueM
            %                   :
            %                   :
            %  # lastPointNumber gammaValue phaseValue
            %  bVar1Value1 bVar2Value1 ... bVarNValue1
            %  bVar1Value2 bVar2Value2 ... bVarNValue2
            %       :           :      ...      :
            %       :           :      ...      :
            %  bVar1ValueM bVar2ValueM ... bVarNValueM
            %  !------------------------------------------------------------- ... -------------------
            %  
            %
            %Responsible person: Ioannis Peppas
            %Contact: Ioannis.Peppas-EE@infineon.com
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section A: import lpcwave file
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            file=readcell(fileName,'FileType','text', ...
                'CommentStyle','!', ...
                'Delimiter',{'\t',' '}, ...
                'ConsecutiveDelimitersRule','join', ...
                'LeadingDelimitersRule','ignore');
            
            file(cellfun(@(x) isa(x,'missing'), file)) = {''};
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section B: convert file into universal 'data' format
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            for i=1:size(file,2)
                temp_bVarNames{1,i} = regexp(file{1,i},'^[a-zA-Z_0-9_|_@]+','once','match');
                temp_bVarUnits{1,i} = regexp(file{1,i},'(?<=\[)[a-zA-Z_0-9_%]*(?=\])','once','match');
            end
            
            blockIndex=0;
            
            i=2;
            while (i<=size(file,1))
                if (strcmp(char(string(file(i,1))),'#'))
                    blockIndex=blockIndex+1;
                    
                    point = file{i,2};
                    gamma = file{i,3};
                    phase = file{i,4};
                    
                    i=i+1;
                    
                elseif isempty(file(i,1))
                    i=i+1;%skip line
                    
                else
                    blockStart=i;
                    k = i;
                    while (~strcmp(char(string(file(k,1))),'#'))
                        k=k+1;
                        if (k>size(file,1))
                            break
                        end
                    end
                    blockStop=k-1;
                    i = k;
                    
                    temp = table2array(rmmissing(cell2table(file(blockStart:blockStop,:)),2));
                    block = [(temp(:,size(temp,2))-1) ones(size(temp,1),1)*point ones(size(temp,1),1)*gamma ones(size(temp,1),1)*phase temp];
                    blockTable=array2table(block,'VariableNames',['Index_Pin' temp_bVarNames]);
                    blockTable=movevars(blockTable,'Point','After','Phase');
                    blockTable=movevars(blockTable,'Psource','Before','Gamma');
                    
                    blockName{1,1} = '';
                    
                    varNames{1,1}  = 'Index_load';
                    varTypes{1,1}  = 0;
                    varValues{1,1} = blockIndex-1;
                    
                    bVarNames = blockTable.Properties.VariableNames;
                    bVarTypes = num2cell(double(~strcmp('Point',bVarNames)));
                    
                    for k=1:size(bVarNames,2)
                        j=find(strcmp(bVarNames{1,k},temp_bVarNames));
                        
                        if isempty(j)
                            bVarUnits{1,k} = '';
                        else
                            bVarUnits{1,k} = temp_bVarUnits{1,j};
                        end
                    end
                    
                    % creating 'data' format
                    dataFormat = {'blockTable','blockName','varNames','varTypes','varValues','bVarNames','bVarTypes','bVarUnits'};
                    data(blockIndex,:)={blockTable,blockName,varNames,varTypes,varValues,bVarNames,bVarTypes,bVarUnits};
                    
                end
                
                
            end
            
            if (size(data,1)==1)
                varNames  = {'Gamma','Phase'};
                varTypes  = {1,1};
                varValues = {gamma,phase};
                data(1,:)={blockTable,blockName,varNames,varTypes,varValues,bVarNames,bVarTypes,bVarUnits};
            end

        end
        
        %File Exporters
        
        function exportMDIF_v1p0(obj, fileName)
            
            %% MDIF File Exporter v1.0
            %Description:
            %  MDIF is a universal file type suitable for importing in ADS
            %  In this format the data/measurements are organized in 'blocks'. There are
            %  'external/outer' variables which are used to sweep between blocks and
            %  'block' variables which are used to organize the data values in columns
            %  inside the block.
            %  
            %  In general these variables have a 'type' which is an integer.
            %  Typical variable types are:
            %  0 -> integer
            %  1 -> real(floating)
            %  2 -> string
            %
            %  Only block variables can also have additional types:
            %  3 -> complex
            %  4 -> boolean
            %  5 -> binary
            %  6 -> octal
            %  7 -> hexadecimal
            %  8 -> byte16
            %
            %Disclaimer:
            %  This script is fairly generic but still is not suitable for the most
            %  generic format of MDIF files.
            %
            %  This script can be used to export any generic MDIF with the condition that
            %  the block variables are formatted in a single line. Multi-line general
            %  formats are not supported by this script.
            %
            %Responsible person: Ioannis Peppas
            %Contact: Ioannis.Peppas-EE@infineon.com
            
            delimiter = '  ';
            
            lineIndex=0;
            
            %% writing comment
            
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! Load Pull Measurement Data']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['!--------------------------------------------------------']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! DATE = ' datestr(datetime)]);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['!--------------------------------------------------------']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! Frequency = ' num2str(obj.Freq(1)/1e9,'%g') ' GHz']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! Char.Impedances = Source: ' num2str(real(obj.Zref1),'%g') ' + ' num2str(imag(obj.Zref1),'%g') 'j Ohm   Load: ' num2str(real(obj.Zref2),'%g') ' + ' num2str(imag(obj.Zref2),'%g') 'j Ohm']);
            
            temp = {'! Source Frequencies ='};
            for i = 1:max(size(obj.Freq))
                harmOrdMsg = {[' F' num2str(i-1) ': ' num2str(obj.Freq(i)/1e9,'%g') ' GHz ']};
                temp = strcat(temp,harmOrdMsg);
            end
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(temp);
            
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['!--------------------------------------------------------']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = " ";
            
            %% writing data in file format
            
            for blockIndex=1:size(obj.data,1)
                blockTable = obj.data{blockIndex,1};
                blockName = obj.data{blockIndex,2};
                
                varNames = obj.data{blockIndex,3};
                varTypes = obj.data{blockIndex,4};
                varValues = obj.data{blockIndex,5};
                
                bVarNames = obj.data{blockIndex,6};
                bVarTypes = obj.data{blockIndex,7};
                bVarUnits = obj.data{blockIndex,8};
                
                for varIndex=1:size(varNames,2)
                    lineIndex = lineIndex + 1;
                    file{lineIndex,1} = string(['VAR ' char(varNames{1,varIndex}) '(' num2str(varTypes{1,varIndex}) ') = ' char(num2str(varValues{1,varIndex},'%g'))]);
                end
                
                lineIndex = lineIndex + 1;
                file{lineIndex,1} = string(['BEGIN ' char(blockName{1,1})]);
                
                for bVarIndex=1:size(bVarNames,2)
                    bVars{1,bVarIndex} = [bVarNames{1,bVarIndex} '(' num2str(bVarTypes{1,bVarIndex}) ')'];
                end
                
                lineIndex = lineIndex + 1;
                file{lineIndex,1} = string(['% ' strjoin(bVars,delimiter)]);
                
                
                for i=1:size(blockTable,1)
                    lineIndex = lineIndex + 1;
                    file{lineIndex,1}= num2str(blockTable{i,:},[delimiter '%G']);
                    
                end
                
                lineIndex = lineIndex + 1;
                file{lineIndex,1} = "END ";
            end
            
            
            %% writing file
            
            writecell(file,'outputFile_exportMDIF_v1p0.txt');
            movefile('outputFile_exportMDIF_v1p0.txt',fileName,'f');
        end
        
        function exportLPCWAVE_v1p0(obj, fileName)
            
            %% LPCwave File Exporter v1.0
            %Description:
            %  LPCwave is a Focus Microwave loadpull data format
            %  In this format the data/measurements are organized in 'blocks'. There are
            %  'external/outer' variables which are used to sweep between blocks and
            %  'block' variables which are used to organize the data values in columns
            %  inside the block.
            %  In general these variables are ALWAYS integer/real
            %  
            %  The general format seems to be:
            %  
            %  !Comments
            %  !------------------------------------------------------------- ... -------------------
            %  Point Gamma Phase[deg] bVar1Name[var1Unit] bVar2Name[var1Unit] ... bVarNName[varNUnit]
            %  !------------------------------------------------------------- ... -------------------
            %  # 001 gammaValue phaseValue
            %  bVar1Value1 bVar2Value1 ... bVarNValue1
            %  bVar1Value2 bVar2Value2 ... bVarNValue2
            %       :           :      ...      :
            %       :           :      ...      :
            %  bVar1ValueM bVar2ValueM ... bVarNValueM
            %  # 002 gammaValue phaseValue
            %  bVar1Value1 bVar2Value1 ... bVarNValue1
            %  bVar1Value2 bVar2Value2 ... bVarNValue2
            %       :           :      ...      :
            %       :           :      ...      :
            %  bVar1ValueM bVar2ValueM ... bVarNValueM
            %                   :
            %                   :
            %  # lastPointNumber gammaValue phaseValue
            %  bVar1Value1 bVar2Value1 ... bVarNValue1
            %  bVar1Value2 bVar2Value2 ... bVarNValue2
            %       :           :      ...      :
            %       :           :      ...      :
            %  bVar1ValueM bVar2ValueM ... bVarNValueM
            %  !------------------------------------------------------------- ... -------------------
            %  
            %
            %Responsible person: Ioannis Peppas
            %Contact: Ioannis.Peppas-EE@infineon.com
            
            delimiter = '  ';
            
            lineIndex=0;
            
            %% writing comment
            
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! Load Pull Measurement Data']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['!--------------------------------------------------------']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! DATE = ' datestr(datetime)]);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['!--------------------------------------------------------']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! Frequency = ' num2str(obj.Freq(1)/1e9,'%g') ' GHz']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! Char.Impedances = Source: ' num2str(real(obj.Zref1),'%g') ' + ' num2str(imag(obj.Zref1),'%g') 'j Ohm   Load: ' num2str(real(obj.Zref2),'%g') ' + ' num2str(imag(obj.Zref2),'%g') 'j Ohm']);
            
            temp = {'! Source Frequencies ='};
            for i = 1:max(size(obj.Freq))
                harmOrdMsg = {[' F' num2str(i-1) ': ' num2str(obj.Freq(i)/1e9,'%g') ' GHz ']};
                temp = strcat(temp,harmOrdMsg);
            end
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(temp);
            
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['!--------------------------------------------------------']);
            
            %% writing data in file format
            
            for blockIndex=1:size(obj.data,1)
                blockTable = obj.data{blockIndex,1};
                blockTable = removevars(blockTable,'Index_Pin');
                blockTable=movevars(blockTable,'Psource','After','Phase');
                blockTable=movevars(blockTable,'Point','Before','Gamma');
                
                if (blockIndex == 1)
                    bVarNames = blockTable.Properties.VariableNames;
                    
                    temp_bVarNames = obj.data{blockIndex,6};
                    temp_bVarUnits = obj.data{blockIndex,8};
                    
                    for bVarIndex=1:size(bVarNames,2)
                        j=find(strcmp(bVarNames{1,bVarIndex},temp_bVarNames));
                        
                        if isempty(j)
                            bVarUnits{1,bVarIndex} = '';
                            
                        else
                            bVarUnits{1,bVarIndex} = temp_bVarUnits{1,j};
                        end
                    end
                    
                    for bVarIndex=1:size(bVarNames,2)
                        if (strcmp(bVarNames{1,bVarIndex},'Point') || strcmp(bVarNames{1,bVarIndex},'Gamma'))
                            bVars{1,bVarIndex} = [bVarNames{1,bVarIndex}];
                        else
                            bVars{1,bVarIndex} = [bVarNames{1,bVarIndex} '[' bVarUnits{1,bVarIndex} ']'];
                        end
                    end
                    
                    lineIndex = lineIndex + 1;
                    file{lineIndex,1} = string(strjoin(bVars,delimiter));
                    lineIndex = lineIndex + 1;
                    file{lineIndex,1} = string(['!--------------------------------------------------------']);
                end
                
                lineIndex = lineIndex + 1;
                file{lineIndex,1} = string(['# ' sprintf( '%03d', blockTable{1,'Point'}) ' ' num2str(blockTable{1,'Gamma'}) ' ' num2str(blockTable{1,'Phase'})]);
                
                blockTable = removevars(blockTable,'Point');
                blockTable = removevars(blockTable,'Gamma');
                blockTable = removevars(blockTable,'Phase');
                
                for i=1:size(blockTable,1)
                    lineIndex = lineIndex + 1;
                    file{lineIndex,1}=num2str(blockTable{i,:},[delimiter '%G']);
                    
                end
                
            end
            
            
            %% writing file
            
            writecell(file,'outputFile_exportMDIF_v1p0.txt');
            movefile('outputFile_exportMDIF_v1p0.txt',fileName,'f');
        end
        
        %Data Calculators
        
        function [power, successfulCalculation, message] = calculatePowerInDelAtFreqFromABWaves_v1p0(obj, portNumber, frequencyIndex, blockNumber)
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulCalculation = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            if ((portNumber ~= 1) && (portNumber ~= 2))
                successfulWrite = 0;
                message = 'Error: Port number should be 1 or 2';
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                successfulWrite = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            [AN, successfulCalculation, message] = ...
                obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('incident', portNumber, frequencyIndex, blockNumber);
            if ~successfulCalculation
                power = 0;
                return
            end
            
            [BN, successfulCalculation, message] = ...
                obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('reflected', portNumber, frequencyIndex, blockNumber);
            if ~successfulCalculation
                power = 0;
                return
            end
            
            if (portNumber == 1)
                ZrefN = obj.Zref1;
            elseif (portNumber == 2)
                ZrefN = obj.Zref2;
            end
            
            successfulCalculation = 1;
            message = 'Successful calculation. Power units in W';
            power = obj.calculateDeliveredInputPower(AN, BN, ZrefN);
        end
        
        function [power, successfulCalculation, message] = calculatePowerAvsAtFreqFromABWaves_v1p0(obj, portNumber, frequencyIndex, blockNumber)
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulCalculation = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            if ((portNumber ~= 1) && (portNumber ~= 2))
                successfulWrite = 0;
                message = 'Error: Port number should be 1 or 2';
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                successfulWrite = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            [BG, successfulCalculation, message] = ...
                obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('incident', portNumber, frequencyIndex, blockNumber);
            if ~successfulCalculation
                power = 0;
                return
            end
            
            [AG, successfulCalculation, message] = ...
                obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('reflected', portNumber, frequencyIndex, blockNumber);
            if ~successfulCalculation
                power = 0;
                return
            end
            
            if (portNumber == 1)
                ZrefS = obj.Zref1;
            elseif (portNumber == 2)
                ZrefS = obj.Zref2;
            end
            
            [gammaS, successfulCalculation, message] =...
                obj.readTargetGamma_FOCUS_MICROWAVE_FORMAT('source', frequencyIndex, blockNumber);
            if ~successfulCalculation
                power = 0;
                return
            end
            
            successfulCalculation = 1;
            message = 'Successful calculation. Power units in W';
            power = obj.calculateAvailableSourcePower(AG, BG, ZrefS, gammaS);
        end
        
        function [power, successfulCalculation, message] = calculatePowerOutDelAtFreqFromABWaves_v1p0(obj, portNumber, frequencyIndex, blockNumber)
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulCalculation = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            if ((portNumber ~= 1) && (portNumber ~= 2))
                successfulWrite = 0;
                message = 'Error: Port number should be 1 or 2';
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                successfulWrite = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            [BL, successfulCalculation, message] = ...
                obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('incident', portNumber, frequencyIndex, blockNumber);
            if ~successfulCalculation
                power = 0;
                return
            end
            
            [AL, successfulCalculation, message] = ...
                obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('reflected', portNumber, frequencyIndex, blockNumber);
            if ~successfulCalculation
                power = 0;
                return
            end
            
            if (portNumber == 1)
                ZrefL = obj.Zref1;
            elseif (portNumber == 2)
                ZrefL = obj.Zref2;
            end
            
            successfulCalculation = 1;
            message = 'Successful calculation. Power units in W';
            power = obj.calculateDeliveredOutputPower(AL, BL, ZrefL);
        end
        
        %Data De-embedding Tools
        
        function [successfulDeembedding, message] = deembedABWaves_v1p0(obj, inputFixtureFileName, outputFixtureFileName, frequencyIndex, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulDeembedding = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                successfulDeembedding = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            % checking input fixture file
            
            if strcmp('unavailable', inputFixtureFileName)
                %disp('Input fixture will not be de-embedded.');
            elseif ~isfile(inputFixtureFileName)
                successfulDeembedding = 0;
                message = 'Error: input fixture file name is incorrect!';
                return
            else
                Stemp = sparameters(inputFixtureFileName);
                if (Stemp.NumPorts ~= 2)
                    successfulDeembedding = 0;
                    message = 'Error: input fixture file is not a 2-port!';
                    return
                elseif ((min(obj.Freq) < min(Stemp.Frequencies))||(max(obj.Freq) > max(Stemp.Frequencies)))
                    successfulDeembedding = 0;
                    message = 'Error: input fixture file has insufficient frequency range!';
                    return
                end
            end
            
            % checking output fixture file
            
            if strcmp('unavailable', outputFixtureFileName)
                %disp('Output fixture will not be de-embedded.');
            elseif ~isfile(outputFixtureFileName)
                successfulDeembedding = 0;
                message = 'Error: output fixture file name is incorrect!';
                return
            else
                Stemp = sparameters(outputFixtureFileName);
                if (Stemp.NumPorts ~= 2)
                    successfulDeembedding = 0;
                    message = 'Error: output fixture file is not a 2-port!';
                    return
                elseif ((min(obj.Freq) < min(Stemp.Frequencies))||(max(obj.Freq) > max(Stemp.Frequencies)))
                    successfulDeembedding = 0;
                    message = 'Error: output fixture file has insufficient frequency range!';
                    return
                end
            end
            
            
            [targetGammaL, successfulDeembedding, message] = obj.readTargetGamma_FOCUS_MICROWAVE_FORMAT('load', frequencyIndex, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            [targetGammaS, successfulDeembedding, message] = obj.readTargetGamma_FOCUS_MICROWAVE_FORMAT('source', frequencyIndex, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            [A1, successfulDeembedding, message] = obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('incident', obj.inputPortNumber, frequencyIndex, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            [B1, successfulDeembedding, message] = obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('reflected', obj.inputPortNumber, frequencyIndex, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            [A2, successfulDeembedding, message] = obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('incident', obj.outputPortNumber, frequencyIndex, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            [B2, successfulDeembedding, message] = obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('reflected', obj.outputPortNumber, frequencyIndex, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            if (obj.inputPortNumber == 1)
                ZrefIn = obj.Zref1;
                ZrefOut = obj.Zref2;
                [targetgammaS, targetgammaL, a1, b1, a2, b2] = obj.deembedABPseudoWaves(...
                    inputFixtureFileName, outputFixtureFileName, obj.Freq(frequencyIndex), ZrefIn, ZrefOut,...
                    targetGammaS, targetGammaL, A1, B1, A2, B2);
                
            else
                ZrefIn = obj.Zref2;
                ZrefOut = obj.Zref1;
                [targetgammaS, targetgammaL, a2, b2, a1, b1] = obj.deembedABPseudoWaves(...
                    inputFixtureFileName, outputFixtureFileName, obj.Freq(frequencyIndex), ZrefIn, ZrefOut,...
                    targetGammaS, targetGammaL, A2, B2, A1, B1);
                
            end
            
            
            [successfulDeembedding, message] = obj.writePseudoWave_FOCUS_MICROWAVE_FORMAT(a1, 'incident', obj.inputPortNumber, frequencyIndex, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            [successfulDeembedding, message] = obj.writePseudoWave_FOCUS_MICROWAVE_FORMAT(b1, 'reflected', obj.inputPortNumber, frequencyIndex, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            [successfulDeembedding, message] = obj.writePseudoWave_FOCUS_MICROWAVE_FORMAT(a2, 'incident', obj.outputPortNumber, frequencyIndex, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            [successfulDeembedding, message] = obj.writePseudoWave_FOCUS_MICROWAVE_FORMAT(b2, 'reflected', obj.outputPortNumber, frequencyIndex, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            [successfulDeembedding, message] = obj.writeTargetGamma_FOCUS_MICROWAVE_FORMAT(targetgammaS, 'source', frequencyIndex, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            [successfulDeembedding, message] = obj.writeTargetGamma_FOCUS_MICROWAVE_FORMAT(targetgammaL, 'load', frequencyIndex, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            successfulDeembedding = 1;
            message = 'Successful de-embedding';
        end
        
        function [successfulDeembedding, message] = deembedPointGamma_v1p0(obj, gammaType, fixtureFileName, frequencyIndex, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulDeembedding = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
                
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                successfulDeembedding = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
                
            end
            
            if (obj.inputPortNumber == 1)
                ZrefIn = obj.Zref1;
                ZrefOut = obj.Zref2;
                
            else
                ZrefIn = obj.Zref2;
                ZrefOut = obj.Zref1;
                
            end
            
            
            [gamma, successfulDeembedding, message] = obj.readPointGamma_FOCUS_MICROWAVE_FORMAT(blockNumber);
            if ~successfulDeembedding
                return
            end
            
            if sum(strcmpi(gammaType,{'L','Load'}))
                gamma = loadpullData.deembedLoadGamma(fixtureFileName, obj.Freq(frequencyIndex), ZrefOut, gamma);
                
            elseif sum(strcmpi(gammaType,{'S','Source'}))
                gamma = loadpullData.deembedSourceGamma(fixtureFileName, obj.Freq(frequencyIndex), ZrefIn, gamma);
                
            else
                gamma = 0;
                successfulDeembedding = 0;
                message = 'Error: Gamma type should be source or load';
                return
                
            end
            
            [successfulDeembedding, message] = obj.writePointGamma_FOCUS_MICROWAVE_FORMAT(gamma, blockNumber);
            if ~successfulDeembedding
                return
            end
            
            successfulDeembedding = 1;
            message = 'Successful de-embedding';
        end
        
        %Data Embedding Tools
        
        function [successfulEmbedding, message] = embedABWaves_v1p0(obj, inputFixtureFileName, outputFixtureFileName, frequencyIndex, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulEmbedding = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                successfulEmbedding = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
            end
            
            % checking input fixture file
            
            if strcmp('unavailable', inputFixtureFileName)
                %disp('Input fixture will not be de-embedded.');
            elseif ~isfile(inputFixtureFileName)
                successfulEmbedding = 0;
                message = 'Error: input fixture file name is incorrect!';
                return
            else
                Stemp = sparameters(inputFixtureFileName);
                if (Stemp.NumPorts ~= 2)
                    successfulEmbedding = 0;
                    message = 'Error: input fixture file is not a 2-port!';
                    return
                elseif ((min(obj.Freq) < min(Stemp.Frequencies))||(max(obj.Freq) > max(Stemp.Frequencies)))
                    successfulEmbedding = 0;
                    message = 'Error: input fixture file has insufficient frequency range!';
                    return
                end
            end
            
            % checking output fixture file
            
            if strcmp('unavailable', outputFixtureFileName)
                %disp('Output fixture will not be de-embedded.');
            elseif ~isfile(outputFixtureFileName)
                successfulEmbedding = 0;
                message = 'Error: output fixture file name is incorrect!';
                return
            else
                Stemp = sparameters(outputFixtureFileName);
                if (Stemp.NumPorts ~= 2)
                    successfulEmbedding = 0;
                    message = 'Error: output fixture file is not a 2-port!';
                    return
                elseif ((min(obj.Freq) < min(Stemp.Frequencies))||(max(obj.Freq) > max(Stemp.Frequencies)))
                    successfulEmbedding = 0;
                    message = 'Error: output fixture file has insufficient frequency range!';
                    return
                end
            end
            
            
            [targetGammaL, successfulEmbedding, message] = obj.readTargetGamma_FOCUS_MICROWAVE_FORMAT('load', frequencyIndex, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            [targetGammaS, successfulEmbedding, message] = obj.readTargetGamma_FOCUS_MICROWAVE_FORMAT('source', frequencyIndex, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            [A1, successfulEmbedding, message] = obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('incident', obj.inputPortNumber, frequencyIndex, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            [B1, successfulEmbedding, message] = obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('reflected', obj.inputPortNumber, frequencyIndex, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            [A2, successfulEmbedding, message] = obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('incident', obj.outputPortNumber, frequencyIndex, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            [B2, successfulEmbedding, message] = obj.readPseudoWave_FOCUS_MICROWAVE_FORMAT('reflected', obj.outputPortNumber, frequencyIndex, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            if (obj.inputPortNumber == 1)
                ZrefIn = obj.Zref1;
                ZrefOut = obj.Zref2;
                [targetgammaS, targetgammaL, a1, b1, a2, b2] = obj.embedABPseudoWaves(...
                    inputFixtureFileName, outputFixtureFileName, obj.Freq(frequencyIndex), ZrefIn, ZrefOut,...
                    targetGammaS, targetGammaL, A1, B1, A2, B2);
                
            else
                ZrefIn = obj.Zref2;
                ZrefOut = obj.Zref1;
                [targetgammaS, targetgammaL, a2, b2, a1, b1] = obj.embedABPseudoWaves(...
                    inputFixtureFileName, outputFixtureFileName, obj.Freq(frequencyIndex), ZrefIn, ZrefOut,...
                    targetGammaS, targetGammaL, A2, B2, A1, B1);
                
            end
            
            
            [successfulEmbedding, message] = obj.writePseudoWave_FOCUS_MICROWAVE_FORMAT(a1, 'incident', obj.inputPortNumber, frequencyIndex, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            [successfulEmbedding, message] = obj.writePseudoWave_FOCUS_MICROWAVE_FORMAT(b1, 'reflected', obj.inputPortNumber, frequencyIndex, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            [successfulEmbedding, message] = obj.writePseudoWave_FOCUS_MICROWAVE_FORMAT(a2, 'incident', obj.outputPortNumber, frequencyIndex, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            [successfulEmbedding, message] = obj.writePseudoWave_FOCUS_MICROWAVE_FORMAT(b2, 'reflected', obj.outputPortNumber, frequencyIndex, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            [successfulEmbedding, message] = obj.writeTargetGamma_FOCUS_MICROWAVE_FORMAT(targetgammaS, 'source', frequencyIndex, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            [successfulEmbedding, message] = obj.writeTargetGamma_FOCUS_MICROWAVE_FORMAT(targetgammaL, 'load', frequencyIndex, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            successfulEmbedding = 1;
            message = 'Successful de-embedding';
        end
        
        function [successfulEmbedding, message] = embedPointGamma_v1p0(obj, gammaType, fixtureFileName, frequencyIndex, blockNumber)
            
            if ~ismember(blockNumber, 1:size(obj.data,1))
                successfulEmbedding = 0;
                message = ['Error: Block number should be integer between min 1 and max ' num2str(size(obj.data,1))];
                return
                
            end
            
            if ~ismember(frequencyIndex, 1:max(size(obj.Freq)))
                successfulEmbedding = 0;
                message = ['Error: Frequency index should be integer between min 1 and max ' num2str(max(size(obj.Freq)))];
                return
                
            end
            
            if (obj.inputPortNumber == 1)
                ZrefIn = obj.Zref1;
                ZrefOut = obj.Zref2;
                
            else
                ZrefIn = obj.Zref2;
                ZrefOut = obj.Zref1;
                
            end
            
            
            [gamma, successfulEmbedding, message] = obj.readPointGamma_FOCUS_MICROWAVE_FORMAT(blockNumber);
            if ~successfulEmbedding
                return
            end
            
            if sum(strcmpi(gammaType,{'L','Load'}))
                gamma = loadpullData.embedLoadGamma(fixtureFileName, obj.Freq(frequencyIndex), ZrefOut, gamma);
                
            elseif sum(strcmpi(gammaType,{'S','Source'}))
                gamma = loadpullData.embedSourceGamma(fixtureFileName, obj.Freq(frequencyIndex), ZrefIn, gamma);
                
            else
                gamma = 0;
                successfulEmbedding = 0;
                message = 'Error: Gamma type should be source or load';
                return
                
            end
            
            [successfulEmbedding, message] = obj.writePointGamma_FOCUS_MICROWAVE_FORMAT(gamma, blockNumber);
            if ~successfulEmbedding
                return
            end
            
            successfulEmbedding = 1;
            message = 'Successful de-embedding';
        end
        
    end
    
    methods (Static)
        
        function PInDel = calculateDeliveredInputPower(aN, bN, ZrefN)
            %Assuming Source is at Port N
            %Calculate the input power delivered to Port N (PinDel)
            %Using the pseudo waves incident aN & reflected bN
            %The port reference impedance ZrefN is required
            
            PInDel = abs(aN).^2-abs(bN).^2+2*imag(aN.*conj(bN))*imag(ZrefN)/real(ZrefN);
            
        end
                
        function PAvS = calculateAvailableSourcePower(ag, bg, ZrefS, gammaS)
            %Calculate the power available from the generator source
            %Using the incident pseudo wave ag (traveling TOWARDS
            %       generator!) usually is b1!
            %and reflected wave bg (traveling AWAY from generator!) usually
            %       is a1!
            %The reference impedance of the source port ZrefS is required 
            %as well
            
            bs = bg - gammaS.*ag;
            PAvS = (abs(bs).^2./((1-abs(gammaS).^2).^2)).*(1-abs(gammaS).^2+2*imag(gammaS).*imag(ZrefS)/real(ZrefS));
        end
        
        function POutDel = calculateDeliveredOutputPower(aL, bL, ZrefL)
            %Calculate the power delivered to the port Load
            %Using the incident pseudo wave aL (traveling TOWARDS
            %       load!) usually is b2!
            %and reflected wave bL (traveling AWAY from load!) usually
            %       is a2!
            %The reference impedance of the load port ZrefL is required 
            %as well
            
            POutDel = abs(aL).^2-abs(bL).^2+2*imag(aL.*conj(bL))*imag(ZrefL)/real(ZrefL);
        end
        
        function [gammaS, gammaL, a1, b1, a2, b2] = deembedABPseudoWaves(...
                inputFixtureFileName, outputFixtureFileName, freq, Zref1, Zref2,...
                GammaS, GammaL, A1, B1, A2, B2)
            %Assuming the source is connected at port 1 and the load is
            %connected at port 2.
            %This function de-embeds the AB pseudo-waves and the source &
            %load gamma.
            %The source & load gamma are references respectively to the
            %port reference impedance Zref1 and Zref2.
            %The AB pseudo waves should also be referenced to the
            %respective port reference impedance.
            %Required are the fixture file names. The fixture files should
            %be in s2p format.
            %Details on AB pseudo waves can be found in the publication:
            %'A General Waveguide Theory' by Roger B. Marks & Dylan F.
            %Williams
            
            s2r = @(S) [S(1,2).*S(2,1)-S(1,1).*S(2,2), S(1,1); -S(2,2), ones(size(S(1,1)))]./S(1,2);%transformation from scattering to cascade matrix
            r2s = @(R) [R(1,2), R(1,1).*R(2,2)-R(1,2).*R(2,1); ones(size(R(1,2))), -R(2,1)]./R(2,2);%transformation from cascade to scattering matrix
            
            if strcmp('unavailable', inputFixtureFileName)
                SfixIn = [0 1; 1 0];
            else
                Stemp = rfinterp1(sparameters(inputFixtureFileName),freq);%sparameter interpolation
                SfixIn = loadpullData.changeReferenceImpedance2Port(Stemp.Parameters, Stemp.Impedance, Zref1, Stemp.Impedance, Zref1);
            end
            
            RfixIn = s2r(SfixIn);
            temp = RfixIn\([B1 A1].');
            a1 = temp(2,:).';
            b1 = temp(1,:).';
            
            gammaIn = b1./a1;
            
            RfixIn11 = RfixIn(1,1);
            RfixIn12 = RfixIn(1,2);
            RfixIn21 = RfixIn(2,1);
            RfixIn22 = RfixIn(2,2);
            gammaS = -(RfixIn21-RfixIn11.*GammaS)./(RfixIn22-RfixIn12.*GammaS);
            
            if strcmp('unavailable', outputFixtureFileName)
                SfixOut = [0 1; 1 0];
            else
                Stemp = rfinterp1(sparameters(outputFixtureFileName),freq);%sparameter interpolation
                SfixOut = loadpullData.changeReferenceImpedance2Port(Stemp.Parameters, Stemp.Impedance, Zref2, Stemp.Impedance, Zref2);
            end
            
            RfixOut = s2r(SfixOut);
            temp = RfixOut*([A2 B2].');
            a2 = temp(1,:).';
            b2 = temp(2,:).';
            
            RfixOut11 = RfixOut(1,1);
            RfixOut12 = RfixOut(1,2);
            RfixOut21 = RfixOut(2,1);
            RfixOut22 = RfixOut(2,2);
            gammaL = (RfixOut11.*GammaL+RfixOut12)./(RfixOut21.*GammaL+RfixOut22);
        end
        
        function gammaS = deembedSourceGamma(inputFixtureFileName, freq, Zref, GammaS)
            %part of 'deembedABPseudoWaves' function
            
            s2r = @(S) [S(1,2).*S(2,1)-S(1,1).*S(2,2), S(1,1); -S(2,2), ones(size(S(1,1)))]./S(1,2);%transformation from scattering to cascade matrix
            r2s = @(R) [R(1,2), R(1,1).*R(2,2)-R(1,2).*R(2,1); ones(size(R(1,2))), -R(2,1)]./R(2,2);%transformation from cascade to scattering matrix
            
            if strcmp('unavailable', inputFixtureFileName)
                SfixIn = [0 1; 1 0];
            else
                Stemp = rfinterp1(sparameters(inputFixtureFileName),freq);%sparameter interpolation
                SfixIn = loadpullData.changeReferenceImpedance2Port(Stemp.Parameters, Stemp.Impedance, Zref, Stemp.Impedance, Zref);
            end
            
            RfixIn = s2r(SfixIn);
            RfixIn11 = RfixIn(1,1);
            RfixIn12 = RfixIn(1,2);
            RfixIn21 = RfixIn(2,1);
            RfixIn22 = RfixIn(2,2);
            gammaS = -(RfixIn21-RfixIn11.*GammaS)./(RfixIn22-RfixIn12.*GammaS);
            
        end
        
        function gammaL = deembedLoadGamma(outputFixtureFileName, freq, Zref, GammaL)
            %part of 'deembedABPseudoWaves' function
            
            s2r = @(S) [S(1,2).*S(2,1)-S(1,1).*S(2,2), S(1,1); -S(2,2), ones(size(S(1,1)))]./S(1,2);%transformation from scattering to cascade matrix
            r2s = @(R) [R(1,2), R(1,1).*R(2,2)-R(1,2).*R(2,1); ones(size(R(1,2))), -R(2,1)]./R(2,2);%transformation from cascade to scattering matrix
            
            if strcmp('unavailable', outputFixtureFileName)
                SfixOut = [0 1; 1 0];
            else
                Stemp = rfinterp1(sparameters(outputFixtureFileName),freq);%sparameter interpolation
                SfixOut = loadpullData.changeReferenceImpedance2Port(Stemp.Parameters, Stemp.Impedance, Zref, Stemp.Impedance, Zref);
            end
            
            RfixOut = s2r(SfixOut);
            
            RfixOut11 = RfixOut(1,1);
            RfixOut12 = RfixOut(1,2);
            RfixOut21 = RfixOut(2,1);
            RfixOut22 = RfixOut(2,2);
            gammaL = (RfixOut11.*GammaL+RfixOut12)./(RfixOut21.*GammaL+RfixOut22);
            
        end
        
        function [GammaS, GammaL, A1, B1, A2, B2] = embedABPseudoWaves(...
                inputFixtureFileName, outputFixtureFileName, freq, Zref1, Zref2,...
                gammaS, gammaL, a1, b1, a2, b2)
            %Assuming the source is connected at port 1 and the load is
            %connected at port 2.
            %This function de-embeds the AB pseudo-waves and the source &
            %load gamma.
            %The source & load gamma are references respectively to the
            %port reference impedance Zref1 and Zref2.
            %The AB pseudo waves should also be referenced to the
            %respective port reference impedance.
            %Required are the fixture file names. The fixture files should
            %be in s2p format.
            %Details on AB pseudo waves can be found in the publication:
            %'A General Waveguide Theory' by Roger B. Marks & Dylan F.
            %Williams
            
            s2r = @(S) [S(1,2).*S(2,1)-S(1,1).*S(2,2), S(1,1); -S(2,2), ones(size(S(1,1)))]./S(1,2);%transformation from scattering to cascade matrix
            r2s = @(R) [R(1,2), R(1,1).*R(2,2)-R(1,2).*R(2,1); ones(size(R(1,2))), -R(2,1)]./R(2,2);%transformation from cascade to scattering matrix
            
            if strcmp('unavailable', inputFixtureFileName)
                SfixIn = [0 1; 1 0];
            else
                Stemp = rfinterp1(sparameters(inputFixtureFileName),freq);%sparameter interpolation
                SfixIn = loadpullData.changeReferenceImpedance2Port(Stemp.Parameters, Stemp.Impedance, Zref1, Stemp.Impedance, Zref1);
            end
            
            RfixIn = s2r(SfixIn);
            temp = RfixIn*([b1, a1].');
            A1 = temp(2,:).';
            B1 = temp(1,:).';
            
            GammaIn = B1./A1;
            
            RfixIn11 = RfixIn(1,1);
            RfixIn12 = RfixIn(1,2);
            RfixIn21 = RfixIn(2,1);
            RfixIn22 = RfixIn(2,2);
            GammaS = (RfixIn21+RfixIn22.*gammaS)./(RfixIn11+RfixIn12.*gammaS);
            
            if strcmp('unavailable', outputFixtureFileName)
                SfixOut = [0 1; 1 0];
            else
                Stemp = rfinterp1(sparameters(outputFixtureFileName),freq);%sparameter interpolation
                SfixOut = loadpullData.changeReferenceImpedance2Port(Stemp.Parameters, Stemp.Impedance, Zref2, Stemp.Impedance, Zref2);
            end
            
            RfixOut = s2r(SfixOut);
            temp = RfixOut\([a2 b2].');
            A2 = temp(1,:).';
            B2 = temp(2,:).';
            
            RfixOut11 = RfixOut(1,1);
            RfixOut12 = RfixOut(1,2);
            RfixOut21 = RfixOut(2,1);
            RfixOut22 = RfixOut(2,2);
            GammaL = (RfixOut12-RfixOut22.*gammaL)./(RfixOut21.*gammaL-RfixOut11);
        end
        
        function GammaS = embedSourceGamma(inputFixtureFileName, freq, Zref, gammaS)
            %part of 'deembedABPseudoWaves' function
            
            s2r = @(S) [S(1,2).*S(2,1)-S(1,1).*S(2,2), S(1,1); -S(2,2), ones(size(S(1,1)))]./S(1,2);%transformation from scattering to cascade matrix
            r2s = @(R) [R(1,2), R(1,1).*R(2,2)-R(1,2).*R(2,1); ones(size(R(1,2))), -R(2,1)]./R(2,2);%transformation from cascade to scattering matrix
            
            if strcmp('unavailable', inputFixtureFileName)
                SfixIn = [0 1; 1 0];
            else
                Stemp = rfinterp1(sparameters(inputFixtureFileName),freq);%sparameter interpolation
                SfixIn = loadpullData.changeReferenceImpedance2Port(Stemp.Parameters, Stemp.Impedance, Zref, Stemp.Impedance, Zref);
            end
            
            RfixIn = s2r(SfixIn);
            RfixIn11 = RfixIn(1,1);
            RfixIn12 = RfixIn(1,2);
            RfixIn21 = RfixIn(2,1);
            RfixIn22 = RfixIn(2,2);
            GammaS = (RfixIn21+RfixIn22.*gammaS)./(RfixIn11+RfixIn12.*gammaS);
            
        end
        
        function GammaL = embedLoadGamma(outputFixtureFileName, freq, Zref, gammaL)
            %part of 'deembedABPseudoWaves' function
            
            s2r = @(S) [S(1,2).*S(2,1)-S(1,1).*S(2,2), S(1,1); -S(2,2), ones(size(S(1,1)))]./S(1,2);%transformation from scattering to cascade matrix
            r2s = @(R) [R(1,2), R(1,1).*R(2,2)-R(1,2).*R(2,1); ones(size(R(1,2))), -R(2,1)]./R(2,2);%transformation from cascade to scattering matrix
            
            if strcmp('unavailable', outputFixtureFileName)
                SfixOut = [0 1; 1 0];
            else
                Stemp = rfinterp1(sparameters(outputFixtureFileName),freq);%sparameter interpolation
                SfixOut = loadpullData.changeReferenceImpedance2Port(Stemp.Parameters, Stemp.Impedance, Zref, Stemp.Impedance, Zref);
            end
            
            RfixOut = s2r(SfixOut);
            
            RfixOut11 = RfixOut(1,1);
            RfixOut12 = RfixOut(1,2);
            RfixOut21 = RfixOut(2,1);
            RfixOut22 = RfixOut(2,2);
            GammaL = (RfixOut12-RfixOut22.*gammaL)./(RfixOut21.*gammaL-RfixOut11);
            
        end
        
        function Snew = changeReferenceImpedance2Port(S, Zref1_old, Zref1_new, Zref2_old, Zref2_new)
            %This function can swap the port reference impedance in the
            %sparameters of a 2 port.
            %Often the LP data are measured with non-50Ohm reference
            %impedance while fixture sparameter measurements are
            %measured with 50Ohm reference impedance.
            %Moving the fixture sparameters to the new reference impedance 
            %is then required.
            
            s2r = @(S) [S(1,2).*S(2,1)-S(1,1).*S(2,2), S(1,1); -S(2,2), ones(size(S(1,1)))]./S(1,2);%transformation from scattering to cascade matrix
            r2s = @(R) [R(1,2), R(1,1).*R(2,2)-R(1,2).*R(2,1); ones(size(R(1,2))), -R(2,1)]./R(2,2);%transformation from cascade to scattering matrix
            
            R = s2r(S);
            
            %% Useful functions
            % Nnm is similar to an ideal impedance transformer's turn-ratio
            Nnm = @(Zrefn, Zrefm) sqrt(Zrefn/Zrefm);
            
            
            % Qnm is the impedance transformer cascade matrix
            Qnm = @(Zrefn, Zrefm) 1/(2*(abs(Nnm(Zrefn, Zrefm))^2))*...
                sqrt(real(Zrefn)/real(Zrefm))*...
                [1+Nnm(Zrefn, Zrefm)^2, 1-Nnm(Zrefn, Zrefm)^2; ...
                1-Nnm(Zrefn, Zrefm)^2, 1+Nnm(Zrefn, Zrefm)^2  ];
            
            %% Calculate impedance transformer port 1
            Q1 = Qnm(Zref1_new,Zref1_old).*ones(size(R(1,1)));
            
            %% Calculate impedance transformer port 2
            Q2 = Qnm(Zref2_old,Zref2_new).*ones(size(R(2,2)));
            
            %% Change reference
            Rnew = Q1*R*Q2;
            Snew = r2s(Rnew);
        end

    end
end

