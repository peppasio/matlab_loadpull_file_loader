clc
clear variables

tic
F0 = 3.6e9;
% inputFixtureFileName = 'unavailable';
inputFixtureFileName = '0_fixtureFiles\mpc_fixture_v1\eb1.s2p';
% outputFixtureFileName = 'unavailable';
outputFixtureFileName = '0_fixtureFiles\mpc_fixture_v1\eb2.s2p';

% fileName = 'DoE_4-5_B0009\SMA Ref\DoE4_5_B0009_run3_I1_8p222-j22p12_I2_2p16+j12p68_I3_SP_I3_matched_3p6GHz_O1_47p34+j20p83_O2_9p763-j113p7_O3_6p477+j91p16_3p6G_80mA_25C_.LPCwave';
loapullType = 'O1';
fileName = 'DoE_4-5_B0009\DoE4_5_B0009_O1_LP_3p6G_80mA.LPCWAVE';
fileType = 'LPCWAVE';
Zref1 = 50;
Zref2 = 50;


addpath('0_dataClasses');
addpath('0_essentialData');
addpath('0_fixtureFiles');

obj = loadpullData(loapullType, [F0, 2*F0, 3*F0], Zref1, Zref2);
obj.import_FOCUS_MICROWAVE_FORMAT(fileName, fileType);
%obj.importUnits_FOCUS_MICROWAVE_FORMAT('0_essentialData/exampleFile.LPCwave');
% [successfulEmbedding, message] = obj.embed_FOCUS_MICROWAVE_FORMAT(inputFixtureFileName, outputFixtureFileName);
[successfulDeembedding, message] = obj.deembed_FOCUS_MICROWAVE_FORMAT(inputFixtureFileName, outputFixtureFileName);
obj.export_FOCUS_MICROWAVE_FORMAT('output.lpcwave', 'LPCWAVE');
obj.export_FOCUS_MICROWAVE_FORMAT('output.mdf', 'MDIF'); 
toc

[power1, successfulCalculation, message] = obj.calculatePowerAtFreq_FOCUS_MICROWAVE_FORMAT('output', 1, 1);
[power2, successfulCalculation, message] = obj.calculatePowerAtFreq_FOCUS_MICROWAVE_FORMAT('output', 2, 1);
[power3, successfulCalculation, message] = obj.calculatePowerAtFreq_FOCUS_MICROWAVE_FORMAT('output', 3, 1);

power1 = 10*log10(abs(power1))+30;
power2 = 10*log10(abs(power2))+30;
power3 = 10*log10(abs(power3))+30;

plot(power1, power1, power1, power2, power1, power3)