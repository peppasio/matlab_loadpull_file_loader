exampleFile.LPCwave can be replaced with any LPCwave file with correct measurements units
This can be used in the case of importing MDIF files, which don't preserve measurement units

