clc
clear variables

F0 = 3.4e9;
Zref1 = 50;
Zref2 = 50;

% fileName = 'DoE_4-5_B0009/DoE4_5_B0009_O1_LP_3p4G_80mA_ADS.mdf';
% fileType = 'MDIF';

fileName = 'DoE_4-5_B0009/DoE4_5_B0009_3p4G_80mA_ADS.mdf';
fileType = 'MDIF';

a = loadpullData([F0, 2*F0, 3*F0], Zref1, Zref2);
a.import_FOCUS_MICROWAVE_FORMAT(fileName, fileType);
a.importUnits_FOCUS_MICROWAVE_FORMAT('DoE_4-5_B0009/DoE4_5_B0009_3p4G_80mA.LPCwave');

dataMDIF = a.data;
a.export_FOCUS_MICROWAVE_FORMAT('outputLPCWAVE_from_MDIF.LPCwave', 'LPCWAVE');

% fileName = 'DoE_4-5_B0009/DoE4_5_B0009_O1_LP_3p4G_80mA.LPCwave';
% fileType = 'LPCWAVE';

fileName = 'DoE_4-5_B0009/DoE4_5_B0009_3p4G_80mA.LPCwave';
fileType = 'LPCWAVE';

b = loadpullData([F0, 2*F0, 3*F0], Zref1, Zref2);
b.import_FOCUS_MICROWAVE_FORMAT(fileName, fileType);

dataLPC = b.data;
b.export_FOCUS_MICROWAVE_FORMAT('outputLPCWAVE_from_LPCWAVE.LPCwave', 'LPCWAVE');

% visdiff('outputLPCWAVE_from_MDIF.LPCwave',fileName);
