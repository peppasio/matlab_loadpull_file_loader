clc
clear variables

fileName = 'LDMOS_7_SMA_3p5G__ADS';

data = readMDF(fileName);

%writeMDF(data, 'outputMDF');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Additional functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function data = readMDF(fileName)
    %'data' is used for 2 reasons:
    %   ->for the processing of the LP data (de-embedding)
    %   ->for the storing of the input MDF file structure (variable names,
    %     begin & end lines, e.t.c.). This simplifies writing the output
    %     MDF file later.
    %
    %The LP data is stored as a table in the last column of 'data'

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%Reading mdf file
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    file=readcell([fileName '.mdf'],'FileType','text', ...
        'CommentStyle','!', ...
        'Delimiter',{'\t',' ','%%'}, ...
        'ConsecutiveDelimitersRule','join', ...
        'LeadingDelimitersRule','ignore'); %'file' is a cell matrix
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%Removing empty cells from 'file'
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    file(cellfun(@(x) isa(x,'missing'), file)) = {char('')};
    
    file=rmmissing(cell2table(file),2);
    file=table2cell(file);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%Reorganizing 'file' into 'data'
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    imax=size(file,1);
    varIndex=0;
    for i=1:imax
        if (strcmp(char(string(file(i,1))),'VAR'))
            varIndex=varIndex+1;
            varLine=strjoin(string(file(i,:)),' ');
        elseif (strcmp(char(string(file(i,1))),'BEGIN'))
            iBegin=i;
        elseif (strcmp(char(string(file(i,1))),'END'))
            iEnd=i;
            
            measNames=file(iBegin+1,:);
            measNamesLine=string(['% ' char(strjoin(string(measNames),' '))]);
            
            measStart=iBegin+2;
            measStop=iEnd-1;
            measArray=table2array(cell2table(file(measStart:measStop,:)));
            
            measTable=array2table(measArray,'VariableNames',measNames);
            
            measLines=convertMeasTable2Str(measTable,'\t');
            data(varIndex,:)={varLine,'BEGIN',measNamesLine,measLines,'END',measTable};
            
        end
        
    end
end

function measLines = convertMeasTable2Str(measTable, Delimiter)
    imax=size(measTable,1);
    
    measLines = strings(imax,1);
    for i=1:imax
        measLines(i)=strjoin(string(table2array(measTable(i,:))),Delimiter);
    end
end

function writeMDF(data, fileName)
    imax=size(data,1);
    j=0;
    for i=1:imax
        j=j+1;
        fileLine{j,1}=data{i,1};
        j=j+1;
        fileLine{j,1}=data{i,2};
        j=j+1;
        fileLine{j,1}=data{i,3};
        
        measLines=data{i,4};
        kmax=size(measLines,1);
        for k=1:kmax
            j=j+1;
            fileLine{j,1}=measLines(k,1);
        end
        
        j=j+1;
        fileLine{j,1}=data{i,5};
    end
    
    writecell(fileLine,[fileName '.txt']);
    
    movefile([fileName '.txt'],[fileName '.mdf'],'f');
    
end


