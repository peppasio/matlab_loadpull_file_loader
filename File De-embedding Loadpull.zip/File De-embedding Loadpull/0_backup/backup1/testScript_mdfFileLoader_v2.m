clc
clear variables

fileName = 'LDMOS_7_SMA_3p5G__ADS';

file=readcell([fileName '.mdf'],'FileType','text', ...
    'CommentStyle','!', ...
    'Delimiter',{'\t',' ','%%'}, ...
    'ConsecutiveDelimitersRule','join', ...
    'LeadingDelimitersRule','ignore'); %'file' is a cell matrix

file(cellfun(@(x) isa(x,'missing'), file)) = {char('')};

file=rmmissing(cell2table(file),2);
file=table2cell(file);

imax=size(file,1);
varIndex=0;

for i=1:imax
    if (strcmp(char(string(file(i,1))),'VAR'))
        
        varIndex=varIndex+1;
        varLine=strjoin(string(file(i,:)),' ');
        
    elseif (strcmp(char(string(file(i,1))),'BEGIN'))
        iBegin=i;
    elseif (strcmp(char(string(file(i,1))),'END'))
        

        iEnd=i;
        
        for j=1:size(file,2)
            measNames{1,j} = regexp(file{iBegin+1,j},'^[a-zA-Z_0-9_|_@]+','once','match');
        end
        
        measNamesLine=string(['% ' char(strjoin(string(measNames),' '))]);
        
        measStart=iBegin+2;
        measStop=iEnd-1;
        
        measArray=table2array(cell2table(file(measStart:measStop,:)));
        
        measTable=array2table(measArray,'VariableNames',measNames);
        
        measLines=convertMeasTable2Str(measTable,'\t');
        dataMDF(varIndex,:)={measTable};
    end
    
end

save('dataMDF.mat', 'dataMDF');

function measLines = convertMeasTable2Str(measTable, Delimiter)
    imax=size(measTable,1);
    
    measLines = strings(imax,1);
    for i=1:imax
        measLines(i)=strjoin(string(table2array(measTable(i,:))),Delimiter);
    end
end
