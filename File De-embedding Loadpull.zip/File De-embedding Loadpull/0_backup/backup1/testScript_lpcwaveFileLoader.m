clear variables

fileName = 'LDMOS_7_SMA_3p5G_';

file=readcell([fileName '.LPCwave'],'FileType','text', ...
    'CommentStyle','!', ...
    'Delimiter',{'\t',' '}, ...
    'ConsecutiveDelimitersRule','join', ...
    'LeadingDelimitersRule','ignore');

file(cellfun(@(x) isa(x,'missing'), file)) = {''};


for i=1:size(file,2)
    measNames{1,i} = regexp(file{1,i},'^[a-zA-Z_0-9_|_@]+','once','match');
end

imax=size(file,1);
varIndex=0;

i=2;
while (i<=imax)
    if (strcmp(char(string(file(i,1))),'#'))
        varIndex=varIndex+1;
        varLine=strjoin(string(file(i,:)),' ');
        
        point = file{i,2};
        gamma = file{i,3};
        phase = file{i,4}; 
        
        i=i+1;
        
    else
        measStart=i
        k = i;
        while (~strcmp(char(string(file(k,1))),'#'))
            k=k+1;
            if (k>imax)
                break
            end
        end
        measStop=k-1
        i = k;
        
        measNamesLine=string([char(strjoin(string(measNames),' '))]);
        
        temp = file(measStart:measStop,:);
        temp = rmmissing(cell2table(temp),2);
        temp = table2array(temp);
        
        sizeTemp1 = size(temp,1);
        sizeTemp2 = size(temp,2);
        measArray = [(temp(:,sizeTemp2)-1) ones(sizeTemp1,1)*point ones(sizeTemp1,1)*gamma ones(sizeTemp1,1)*phase temp];
        
        measTable=array2table(measArray,'VariableNames',['Index_Pin' measNames]);
        
        measTable=movevars(measTable,'Point','After','Phase');
        measTable=movevars(measTable,'Psource','Before','Gamma');
        
        measLines=convertMeasTable2Str(measTable,'\t');
        dataLPC(varIndex,:)={measTable};
        
        input(['VarIndex ' num2str(varIndex) ' Gamma=' num2str(table2array(measTable(1,'Gamma'))) ' Phase=' num2str(table2array(measTable(1,'Phase')))]);
    end
end

save('dataLPC.mat', 'dataLPC');

function measLines = convertMeasTable2Str(measTable, Delimiter)
    imax=size(measTable,1);
    
    measLines = strings(imax,1);
    for i=1:imax
        measLines(i)=strjoin(string(table2array(measTable(i,:))),Delimiter);
    end
end
