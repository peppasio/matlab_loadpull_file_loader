classdef loadpullData < handle
    
    properties (Access = public)
        %% frequency data
        Freq %Frequency vector. Frequencies in Hz.
        
        %% Loadpull Data
        data
        dataFormat
        
        %% Port 1 Reference Impedance
        Zref1
        
        %% Port 2 Reference Impedance
        Zref2
    end
    
    methods (Access = public)
        function obj = loadpullData(Freq, Zref1, Zref2)
            %Construct an instance of this class
            %Freq Frequency Vector in Hz
            %Zref1 reference impedance of port1
            %Zref2 reference impedance of port2
            
            obj.Freq = Freq;
            obj.Zref1 = Zref1;
            obj.Zref2 = Zref2;
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% FOCUS MICROWAVE TOOLS
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        function import_FOCUS_MICROWAVE_FORMAT(obj, fileName, fileType)
            if (strcmp(fileType,"MDIF"))
                [obj.data,obj.dataFormat] = obj.importMDIF_v1p0(fileName);
                
            elseif (strcmp(fileType,"LPCWAVE"))
                [obj.data,obj.dataFormat] = obj.importLPCWAVE_v1p0(fileName);
                
            elseif (strcmp(fileType,""))
                %the data will be manually inserted
                %do nothing here
                disp('Manual data definition.')
                
            else
                disp('Unknown data format!')
                
            end
        end
        
        function importUnits_FOCUS_MICROWAVE_FORMAT(obj, exampleFileName)
            %  This function can be used to import measurement units.
            %  
            %  MDIF files DO NOT preserve measurement units for block
            %  variables. However LPCwave files DO preserve measurement
            %  units. If the measurement units are needed, they can be
            %  recovered from an 'example' file with LPCwave format as long
            %  as the block variable names are preserved between the
            %  imported and 'example' files.
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section A: import example lpcwave file
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            file=readcell(exampleFileName,'FileType','text', ...
                'CommentStyle','!', ...
                'Delimiter',{'\t',' '}, ...
                'ConsecutiveDelimitersRule','join', ...
                'LeadingDelimitersRule','ignore');
            
            file(cellfun(@(x) isa(x,'missing'), file)) = {''};
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section B: extract example variable names & units
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            for i=1:size(file,2)
                examplebVarNames{1,i} = regexp(file{1,i},'^[a-zA-Z_0-9_|_@]+','once','match');
                examplebVarUnits{1,i} = regexp(file{1,i},'(?<=\[)[a-zA-Z_0-9_%]*(?=\])','once','match');
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section C: copy from example variable names & units
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            for k=1:size(obj.data,1)
                bVarNames = obj.data{k,6};
                for i=1:size(bVarNames,2)
                    j=find(strcmp(bVarNames{1,i},examplebVarNames));
                    
                    if isempty(j)
                        bVarUnits{1,i} = '';
                    else
                        bVarUnits{1,i} = examplebVarUnits{1,j};
                    end
                end
                obj.data{k,8} = bVarUnits;
            end
            
        end
        
        function export_FOCUS_MICROWAVE_FORMAT(obj, fileName, fileType)
            
            if (strcmp(fileType,"MDIF"))
                obj.exportMDIF_v1p0(fileName);
            elseif (strcmp(fileType,"LPCWAVE"))
                obj.exportLPCWAVE_v1p0(fileName);
            else
                disp('Unknown format!')
            end
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% ANTEVERTA TOOLS
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    end
    
    methods (Access = private)
        
        %% File Importers - FOCUS MICROWAVE FORMAT
        
        function [data, dataFormat] = importMDIF_v1p0(obj,fileName)
            %% MDIF File Importer v1.0
            %Description:
            %  MDIF is a universal file type suitable for importing in ADS
            %  In this format the data/measurements are organized in 'blocks'. There are
            %  'external/outer' variables which are used to sweep between blocks and
            %  'block' variables which are used to organize the data values in columns
            %  inside the block.
            %  
            %  In general these variables have a 'type' which is an integer.
            %  Typical variable types are:
            %  0 -> integer
            %  1 -> real(floating)
            %  2 -> string
            %
            %  Only block variables can also have additional types:
            %  3 -> complex
            %  4 -> boolean
            %  5 -> binary
            %  6 -> octal
            %  7 -> hexadecimal
            %  8 -> byte16
            %
            %Disclaimer:
            %  This script is fairly generic but still is not suitable for the most
            %  generic format of MDIF files.
            %
            %  This script can be used to load any generic MDIF with the condition that
            %  the block variables are formatted in a single line. Multi-line general
            %  formats are not supported by this script.
            %
            %Responsible person: Ioannis Peppas
            %Contact: Ioannis.Peppas-EE@infineon.com
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section A: import mdf file
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            file=readcell(fileName,'FileType','text', ...
                'CommentStyle','!', ...
                'Delimiter',{'\t',' ','%%'}, ...
                'ConsecutiveDelimitersRule','join', ...
                'LeadingDelimitersRule','ignore'); %'file' is a cell matrix
            
            file(cellfun(@(x) isa(x,'missing'), file)) = {char('')};
            file=rmmissing(cell2table(file),2);% remove empty cells
            file=table2cell(file);
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section B: convert file into universal 'data' format
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            blockIndex=0;
            varIndex=0;
            
            for i=1:size(file,1)
                if (strcmp(file{i,1},'VAR'))
                    % reading 'external' variables
                    varIndex=varIndex+1;
                    varNames{1,varIndex}  = regexp(file{i,2},'^[a-zA-Z_0-9_|_@]+','once','match');
                    varTypes{1,varIndex}  = str2num(regexp(file{i,2},'(?<=\()[^)]*(?=\))','once','match'));
                    varValues{1,varIndex} = file{i,4};
                    
                elseif (strcmp(file{i,1},'BEGIN'))
                    % this is the start of the block
                    blockIndex=blockIndex+1;
                    iBlockBegin=i;
                    blockName{1,1} = file{i,2};
                    
                elseif (strcmp(file{i,1},'END'))
                    % this is the end of the block
                    varIndex=0;
                    iBlockEnd=i;
                    
                    % reading 'block' variables
                    for j=1:size(file,2)
                        bVarNames{1,j} = regexp(file{iBlockBegin+1,j},'^[a-zA-Z_0-9_|_@]+','once','match');
                        bVarTypes{1,j} = regexp(file{iBlockBegin+1,j},'(?<=\()[^)]*(?=\))','once','match');
                        bVarUnits{1,j} = '';
                    end
                    
                    % reading block
                    block=table2array(cell2table(file((iBlockBegin+2):(iBlockEnd-1),:)));
                    blockTable=array2table(block,'VariableNames',bVarNames);
                    
                    % creating 'data' format
                    dataFormat = {'blockTable','blockName','varNames','varTypes','varValues','bVarNames','bVarTypes','bVarUnits'};
                    data(blockIndex,:)={blockTable,blockName,varNames,varTypes,varValues,bVarNames,bVarTypes,bVarUnits};
                    
                end
            end
        end
        
        function [data, dataFormat] = importLPCWAVE_v1p0(obj,fileName)
            %% LPCwave File Importer v1.0
            %Description:
            %  LPCwave is a Focus Microwave loadpull data format
            %  In this format the data/measurements are organized in 'blocks'. There are
            %  'external/outer' variables which are used to sweep between blocks and
            %  'block' variables which are used to organize the data values in columns
            %  inside the block.
            %  In general these variables are ALWAYS integer/real
            %  
            %  The general format seems to be:
            %  
            %  !Comments
            %  !------------------------------------------------------------- ... -------------------
            %  Point Gamma Phase[deg] bVar1Name[var1Unit] bVar2Name[var1Unit] ... bVarNName[varNUnit]
            %  !------------------------------------------------------------- ... -------------------
            %  # 001 gammaValue phaseValue
            %  bVar1Value1 bVar2Value1 ... bVarNValue1
            %  bVar1Value2 bVar2Value2 ... bVarNValue2
            %       :           :      ...      :
            %       :           :      ...      :
            %  bVar1ValueM bVar2ValueM ... bVarNValueM
            %  # 002 gammaValue phaseValue
            %  bVar1Value1 bVar2Value1 ... bVarNValue1
            %  bVar1Value2 bVar2Value2 ... bVarNValue2
            %       :           :      ...      :
            %       :           :      ...      :
            %  bVar1ValueM bVar2ValueM ... bVarNValueM
            %                   :
            %                   :
            %  # lastPointNumber gammaValue phaseValue
            %  bVar1Value1 bVar2Value1 ... bVarNValue1
            %  bVar1Value2 bVar2Value2 ... bVarNValue2
            %       :           :      ...      :
            %       :           :      ...      :
            %  bVar1ValueM bVar2ValueM ... bVarNValueM
            %  !------------------------------------------------------------- ... -------------------
            %  
            %
            %Responsible person: Ioannis Peppas
            %Contact: Ioannis.Peppas-EE@infineon.com
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section A: import lpcwave file
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            file=readcell(fileName,'FileType','text', ...
                'CommentStyle','!', ...
                'Delimiter',{'\t',' '}, ...
                'ConsecutiveDelimitersRule','join', ...
                'LeadingDelimitersRule','ignore');
            
            file(cellfun(@(x) isa(x,'missing'), file)) = {''};
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Section B: convert file into universal 'data' format
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            for i=1:size(file,2)
                temp_bVarNames{1,i} = regexp(file{1,i},'^[a-zA-Z_0-9_|_@]+','once','match');
                temp_bVarUnits{1,i} = regexp(file{1,i},'(?<=\[)[a-zA-Z_0-9_%]*(?=\])','once','match');
            end
            
            blockIndex=0;
            
            i=2;
            while (i<=size(file,1))
                if (strcmp(char(string(file(i,1))),'#'))
                    blockIndex=blockIndex+1;
                    
                    point = file{i,2};
                    gamma = file{i,3};
                    phase = file{i,4};
                    
                    i=i+1;
                    
                elseif isempty(file(i,1))
                    i=i+1;%skip line
                    
                else
                    blockStart=i;
                    k = i;
                    while (~strcmp(char(string(file(k,1))),'#'))
                        k=k+1;
                        if (k>size(file,1))
                            break
                        end
                    end
                    blockStop=k-1;
                    i = k;
                    
                    temp = table2array(rmmissing(cell2table(file(blockStart:blockStop,:)),2));
                    block = [(temp(:,size(temp,2))-1) ones(size(temp,1),1)*point ones(size(temp,1),1)*gamma ones(size(temp,1),1)*phase temp];
                    blockTable=array2table(block,'VariableNames',['Index_Pin' temp_bVarNames]);
                    blockTable=movevars(blockTable,'Point','After','Phase');
                    blockTable=movevars(blockTable,'Psource','Before','Gamma');
                    
                    blockName{1,1} = '';
                    
                    varNames{1,1}  = 'Index_load';
                    varTypes{1,1}  = 0;
                    varValues{1,1} = blockIndex-1;
                    
                    bVarNames = blockTable.Properties.VariableNames;
                    bVarTypes = num2cell(double(~strcmp('Point',bVarNames)));
                    
                    for k=1:size(bVarNames,2)
                        j=find(strcmp(bVarNames{1,k},temp_bVarNames));
                        
                        if isempty(j)
                            bVarUnits{1,k} = '';
                        else
                            bVarUnits{1,k} = temp_bVarUnits{1,j};
                        end
                    end
                    
                    % creating 'data' format
                    dataFormat = {'blockTable','blockName','varNames','varTypes','varValues','bVarNames','bVarTypes','bVarUnits'};
                    data(blockIndex,:)={blockTable,blockName,varNames,varTypes,varValues,bVarNames,bVarTypes,bVarUnits};
                    
                end
                
                
            end
            
            if (size(data,1)==1)
                varNames  = {'Gamma','Phase'};
                varTypes  = {1,1};
                varValues = {gamma,phase};
                data(1,:)={blockTable,blockName,varNames,varTypes,varValues,bVarNames,bVarTypes,bVarUnits};
            end

        end
        
        %% File Exporters - FOCUS MICROWAVE FORMAT
        
        function exportMDIF_v1p0(obj, fileName)
            
            %% MDIF File Exporter v1.0
            %Description:
            %  MDIF is a universal file type suitable for importing in ADS
            %  In this format the data/measurements are organized in 'blocks'. There are
            %  'external/outer' variables which are used to sweep between blocks and
            %  'block' variables which are used to organize the data values in columns
            %  inside the block.
            %  
            %  In general these variables have a 'type' which is an integer.
            %  Typical variable types are:
            %  0 -> integer
            %  1 -> real(floating)
            %  2 -> string
            %
            %  Only block variables can also have additional types:
            %  3 -> complex
            %  4 -> boolean
            %  5 -> binary
            %  6 -> octal
            %  7 -> hexadecimal
            %  8 -> byte16
            %
            %Disclaimer:
            %  This script is fairly generic but still is not suitable for the most
            %  generic format of MDIF files.
            %
            %  This script can be used to export any generic MDIF with the condition that
            %  the block variables are formatted in a single line. Multi-line general
            %  formats are not supported by this script.
            %
            %Responsible person: Ioannis Peppas
            %Contact: Ioannis.Peppas-EE@infineon.com
            
            delimiter = '\t';
            
            lineIndex=0;
            
            %% writing comment
            
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! Load Pull Measurement Data']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['!--------------------------------------------------------']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! DATE = ' datestr(datetime)]);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['!--------------------------------------------------------']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! Frequency = ' num2str(obj.Freq(1)/1e9,'%g') ' GHz']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! Char.Impedances = Source: ' num2str(real(obj.Zref1),'%g') ' + ' num2str(imag(obj.Zref1),'%g') 'j Ohm   Load: ' num2str(real(obj.Zref2),'%g') ' + ' num2str(imag(obj.Zref2),'%g') 'j Ohm']);
            
            temp = {'! Source Frequencies ='};
            for i = 1:max(size(obj.Freq))
                harmOrdMsg = {[' F' num2str(i-1) ': ' num2str(obj.Freq(i)/1e9,'%g') ' GHz ']};
                temp = strcat(temp,harmOrdMsg);
            end
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(temp);
            
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['!--------------------------------------------------------']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = " ";
            
            %% writing data in file format
            
            for blockIndex=1:size(obj.data,1)
                blockTable = obj.data{blockIndex,1};
                blockName = obj.data{blockIndex,2};
                
                varNames = obj.data{blockIndex,3};
                varTypes = obj.data{blockIndex,4};
                varValues = obj.data{blockIndex,5};
                
                bVarNames = obj.data{blockIndex,6};
                bVarTypes = obj.data{blockIndex,7};
                bVarUnits = obj.data{blockIndex,8};
                
                for varIndex=1:size(varNames,2)
                    lineIndex = lineIndex + 1;
                    file{lineIndex,1} = string(['VAR ' char(varNames{1,varIndex}) '(' num2str(varTypes{1,varIndex}) ') = ' char(num2str(varValues{1,varIndex}))]);
                end
                
                lineIndex = lineIndex + 1;
                file{lineIndex,1} = string(['BEGIN ' char(blockName{1,1})]);
                
                for bVarIndex=1:size(bVarNames,2)
                    bVars{1,bVarIndex} = [bVarNames{1,bVarIndex} '(' num2str(bVarTypes{1,bVarIndex}) ')'];
                end
                
                lineIndex = lineIndex + 1;
                file{lineIndex,1} = string(['% ' strjoin(bVars,delimiter)]);
                
                
                for i=1:size(blockTable,1)
                    lineIndex = lineIndex + 1;
                    file{lineIndex,1}=strjoin(string(table2array(blockTable(i,:))),delimiter);
                end
                
                lineIndex = lineIndex + 1;
                file{lineIndex,1} = "END ";
            end
            
            
            %% writing file
            
            writecell(file,'outputFile_exportMDIF_v1p0.txt');
            movefile('outputFile_exportMDIF_v1p0.txt',fileName,'f');
        end
        
        function exportLPCWAVE_v1p0(obj, fileName)
            
            %% LPCwave File Exporter v1.0
            %Description:
            %  LPCwave is a Focus Microwave loadpull data format
            %  In this format the data/measurements are organized in 'blocks'. There are
            %  'external/outer' variables which are used to sweep between blocks and
            %  'block' variables which are used to organize the data values in columns
            %  inside the block.
            %  In general these variables are ALWAYS integer/real
            %  
            %  The general format seems to be:
            %  
            %  !Comments
            %  !------------------------------------------------------------- ... -------------------
            %  Point Gamma Phase[deg] bVar1Name[var1Unit] bVar2Name[var1Unit] ... bVarNName[varNUnit]
            %  !------------------------------------------------------------- ... -------------------
            %  # 001 gammaValue phaseValue
            %  bVar1Value1 bVar2Value1 ... bVarNValue1
            %  bVar1Value2 bVar2Value2 ... bVarNValue2
            %       :           :      ...      :
            %       :           :      ...      :
            %  bVar1ValueM bVar2ValueM ... bVarNValueM
            %  # 002 gammaValue phaseValue
            %  bVar1Value1 bVar2Value1 ... bVarNValue1
            %  bVar1Value2 bVar2Value2 ... bVarNValue2
            %       :           :      ...      :
            %       :           :      ...      :
            %  bVar1ValueM bVar2ValueM ... bVarNValueM
            %                   :
            %                   :
            %  # lastPointNumber gammaValue phaseValue
            %  bVar1Value1 bVar2Value1 ... bVarNValue1
            %  bVar1Value2 bVar2Value2 ... bVarNValue2
            %       :           :      ...      :
            %       :           :      ...      :
            %  bVar1ValueM bVar2ValueM ... bVarNValueM
            %  !------------------------------------------------------------- ... -------------------
            %  
            %
            %Responsible person: Ioannis Peppas
            %Contact: Ioannis.Peppas-EE@infineon.com
            
            delimiter = ' ';
            
            lineIndex=0;
            
            %% writing comment
            
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! Load Pull Measurement Data']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['!--------------------------------------------------------']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! DATE = ' datestr(datetime)]);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['!--------------------------------------------------------']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! Frequency = ' num2str(obj.Freq(1)/1e9,'%g') ' GHz']);
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['! Char.Impedances = Source: ' num2str(real(obj.Zref1),'%g') ' + ' num2str(imag(obj.Zref1),'%g') 'j Ohm   Load: ' num2str(real(obj.Zref2),'%g') ' + ' num2str(imag(obj.Zref2),'%g') 'j Ohm']);
            
            temp = {'! Source Frequencies ='};
            for i = 1:max(size(obj.Freq))
                harmOrdMsg = {[' F' num2str(i-1) ': ' num2str(obj.Freq(i)/1e9,'%g') ' GHz ']};
                temp = strcat(temp,harmOrdMsg);
            end
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(temp);
            
            lineIndex = lineIndex + 1;
            file{lineIndex,1} = string(['!--------------------------------------------------------']);
            
            %% writing data in file format
            
            for blockIndex=1:size(obj.data,1)
                blockTable = obj.data{blockIndex,1};
                blockTable = removevars(blockTable,'Index_Pin');
                blockTable=movevars(blockTable,'Psource','After','Phase');
                blockTable=movevars(blockTable,'Point','Before','Gamma');
                
                if (blockIndex == 1)
                    bVarNames = blockTable.Properties.VariableNames;
                    
                    temp_bVarNames = obj.data{blockIndex,6};
                    temp_bVarUnits = obj.data{blockIndex,8};
                    
                    for bVarIndex=1:size(bVarNames,2)
                        j=find(strcmp(bVarNames{1,bVarIndex},temp_bVarNames));
                        
                        if isempty(j)
                            bVarUnits{1,bVarIndex} = '';
                            
                        else
                            bVarUnits{1,bVarIndex} = temp_bVarUnits{1,j};
                        end
                    end
                    
                    for bVarIndex=1:size(bVarNames,2)
                        if (strcmp(bVarNames{1,bVarIndex},'Point') || strcmp(bVarNames{1,bVarIndex},'Gamma'))
                            bVars{1,bVarIndex} = [bVarNames{1,bVarIndex}];
                        else
                            bVars{1,bVarIndex} = [bVarNames{1,bVarIndex} '[' bVarUnits{1,bVarIndex} ']'];
                        end
                    end
                    
                    lineIndex = lineIndex + 1;
                    file{lineIndex,1} = string(strjoin(bVars,delimiter));
                    lineIndex = lineIndex + 1;
                    file{lineIndex,1} = string(['!--------------------------------------------------------']);
                end
                
                lineIndex = lineIndex + 1;
                file{lineIndex,1} = string(['# ' sprintf( '%03d', blockTable{1,'Point'}) ' ' num2str(blockTable{1,'Gamma'}) ' ' num2str(blockTable{1,'Phase'})]);
                
                blockTable = removevars(blockTable,'Point');
                blockTable = removevars(blockTable,'Gamma');
                blockTable = removevars(blockTable,'Phase');
                
                for i=1:size(blockTable,1)
                    lineIndex = lineIndex + 1;
                    file{lineIndex,1}=strjoin(string(table2array(blockTable(i,:))),delimiter);
                end
                
            end
            
            
            %% writing file
            
            writecell(file,'outputFile_exportMDIF_v1p0.txt');
            movefile('outputFile_exportMDIF_v1p0.txt',fileName,'f');
        end
        
        %% Data De-embedding Methods
        
    end
    
    methods (Static)
        
        function PIn = calculateInputPower(aN, bN, ZrefN)
            %Assuming Source is at Port N
            %Calculate the power inserted at Port N (Pin)
            %Using the pseudo waves incident aN & reflected bN
            %The port reference impedance ZrefN is required
            
            PIn = abs(aN).^2-abs(bN).^2+2*imag(aN.*conj(bN))*imag(ZrefN)/real(ZrefN);
            
        end
        
        function PAvS = calculateAvailableSourcePower(ag, bg, ZrefS, gammaS)
            %Calculate the power available from the generator source
            %Using the incident pseudo wave ag (traveling TOWARDS
            %       generator!) usually is b1!
            %and reflected wave bg (traveling AWAY from generator!) usually
            %       is a1!
            %The reference impedance of the source port ZrefS is required 
            %as well
            
            bs = bg - gammaS.*ag;
            PAvGen = (abs(bs).^2./((1-abs(gammaS).^2).^2)).*(1-abs(gammaS).^2+2*imag(gammaS).*imag(ZrefS)/real(ZrefS));
        end
        
        function PDel = calculateDeliveredPower(aL, bL, ZrefL)
            %Calculate the power delivered to the port Load
            %Using the incident pseudo wave aL (traveling TOWARDS
            %       load!) usually is b2!
            %and reflected wave bL (traveling AWAY from load!) usually
            %       is a2!
            %The reference impedance of the load port ZrefL is required 
            %as well
            
            PDel = abs(aL).^2-abs(bL).^2+2*imag(aL.*conj(bL))*imag(ZrefL)/real(ZrefL);
        end
        
        function [gammaS, gammaL, a1, b1, a2, b2] = deembedABPseudoWaves(...
                inputFixtureFileName, outputFixtureFileName, freq, Zref1, Zref2,...
                GammaS, GammaL, A1, B1, A2, B2)
            %Assuming the source is connected at port 1 and the load is
            %connected at port 2.
            %This function de-embeds the AB pseudo-waves and the source &
            %load gamma.
            %The source & load gamma are references respectively to the
            %port reference impedance Zref1 and Zref2.
            %The AB pseudo waves should also be referenced to the
            %respective port reference impedance.
            %Required are the fixture file names. The fixture files should
            %be in s2p format.
            %Details on AB pseudo waves can be found in the publication:
            %'A General Waveguide Theory' by Roger B. Marks & Dylan F.
            %Williams
            
            s2r = @(S) [S(1,2).*S(2,1)-S(1,1).*S(2,2), S(1,1); -S(2,2), ones(size(S(1,1)))]./S(1,2);%transformation from scattering to cascade matrix
            r2s = @(R) [R(1,2), R(1,1).*R(2,2)-R(1,2).*R(2,1); ones(size(R(1,2))), -R(2,1)]./R(2,2);%transformation from cascade to scattering matrix
            
            Stemp = rfinterp1(sparameters(inputFixtureFileName),freq);%sparameter interpolation
            SfixIn = changeReferenceImpedance2Port(Stemp.Parameters, Stemp.Impedance, Zref1, Stemp.Impedance, Zref1);
            RfixIn = s2r(SfixIn);
            temp = RfixIn\([B1 A1].');
            a1 = temp(2,:).';
            b1 = temp(1,:).';
            
            gammaIn = b1./a1;
            
            RfixIn11 = RfixIn(1,1);
            RfixIn12 = RfixIn(1,2);
            RfixIn21 = RfixIn(2,1);
            RfixIn22 = RfixIn(2,2);
            gammaS = -(RfixIn21-RfixIn11.*GammaS)./(RfixIn22-RfixIn12.*GammaS);
            
            Stemp = rfinterp1(sparameters(outputFixtureFileName),freq);%sparameter interpolation
            SfixOut = changeReferenceImpedance2Port(Stemp.Parameters, Stemp.Impedance, Zref2, Stemp.Impedance, Zref2);
            RfixOut = s2r(SfixOut);
            temp = RfixOut*([A2 B2].');
            a2 = temp(1,:).';
            b2 = temp(2,:).';
            
            gammaL = a2./b2;
        end
        
        function Snew = changeReferenceImpedance2Port(S, Zref1_old, Zref1_new, Zref2_old, Zref2_new)
            %This function can swap the port reference impedance in the
            %sparameters of a 2 port.
            %Often the LP data are measured with non-50Ohm reference
            %impedance while fixture sparameter measurements are
            %measured with 50Ohm reference impedance.
            %Moving the fixture sparameters to the new reference impedance 
            %is then required.
            
            s2r = @(S) [S(1,2).*S(2,1)-S(1,1).*S(2,2), S(1,1); -S(2,2), ones(size(S(1,1)))]./S(1,2);%transformation from scattering to cascade matrix
            r2s = @(R) [R(1,2), R(1,1).*R(2,2)-R(1,2).*R(2,1); ones(size(R(1,2))), -R(2,1)]./R(2,2);%transformation from cascade to scattering matrix
            
            R = s2r(S);
            
            %% Useful functions
            % Nnm is similar to an ideal impedance transformer's turn-ratio
            Nnm = @(Zrefn, Zrefm) sqrt(Zrefn/Zrefm);
            
            
            % Qnm is the impedance transformer cascade matrix
            Qnm = @(Zrefn, Zrefm) 1/(2*(abs(Nnm(Zrefn, Zrefm))^2))*...
                sqrt(real(Zrefn)/real(Zrefm))*...
                [1+Nnm(Zrefn, Zrefm)^2, 1-Nnm(Zrefn, Zrefm)^2; ...
                1-Nnm(Zrefn, Zrefm)^2, 1+Nnm(Zrefn, Zrefm)^2  ];
            
            %% Calculate impedance transformer port 1
            Q1 = Qnm(Zref1_new,Zref1_old).*ones(size(R(1,1)));
            
            %% Calculate impedance transformer port 2
            Q2 = Qnm(Zref2_old,Zref2_new).*ones(size(R(2,2)));
            
            %% Change reference
            Rnew = Q1*R*Q2;
            Snew = r2s(Rnew);
        end

    end
end

