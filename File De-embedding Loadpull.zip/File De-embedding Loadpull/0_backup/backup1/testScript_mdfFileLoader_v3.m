clc
clear variables

fileName = 'DoE_4-5_B0009/DoE4_5_B0009_O1_LP_3p4G_80mA_ADS.mdf';

%% MDIF File Loader v3.0
%Description:
%  .mdf is a universal file type suitable for importing in ADS
%  In tis format the data/measurements are organized in 'blocks'. There are
%  'external/outer' variables which are used to sweep between blocks and
%  'block' variables which are used to organize the data values in columns 
%  inside the block.
%  In general these variables have a 'type' which is an integer.
%  
%  Typical variable types are:
%  0 -> integer
%  1 -> real(floating)
%  2 -> string
%  
%  Only block variables can also have additional types:
%  3 -> complex
%  4 -> boolean
%  5 -> binary
%  6 -> octal
%  7 -> hexadecimal
%  8 -> byte16
%  
%Disclaimer:
%  This script is fairly generic but still is not suitable for the most
%  generic format of MDIF files.
%  
%  This script can be used to load any generic MDIF with the condition that
%  the block variables are formatted in a single line. Multi-line general
%  formats are not supported by this script.
%  
%Responsible person: Ioannis Peppas
%Contact: Ioannis.Peppas-EE@infineon.com

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Section A: import mdf file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

file=readcell(fileName,'FileType','text', ...
    'CommentStyle','!', ...
    'Delimiter',{'\t',' ','%%'}, ...
    'ConsecutiveDelimitersRule','join', ...
    'LeadingDelimitersRule','ignore'); %'file' is a cell matrix

file(cellfun(@(x) isa(x,'missing'), file)) = {char('')};
file=rmmissing(cell2table(file),2);% remove empty cells
file=table2cell(file);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Section B: convert file into universal 'data' format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

blockIndex=0;
varIndex=0;

for i=1:size(file,1)
    if (strcmp(char(string(file(i,1))),'VAR'))
        % reading 'external' variables
        varIndex=varIndex+1;
        varNames{1,varIndex}  = regexp(file{i,2},'^[a-zA-Z_0-9_|_@]+','once','match');
        varTypes{1,varIndex}  = str2num(regexp(file{i,2},'(?<=\()[^)]*(?=\))','once','match'));
        varValues{1,varIndex} = file{i,4};
        
    elseif (strcmp(char(string(file(i,1))),'BEGIN'))
        % this is the start of the block
        blockIndex=blockIndex+1;
        iBlockBegin=i;
        blockName = string(file(i,2));
        
    elseif (strcmp(char(string(file(i,1))),'END'))
        % this is the end of the block
        varIndex=0;
        iBlockEnd=i;
        
        % reading 'block' variables
        for j=1:size(file,2)
            bVarNames{1,j} = regexp(file{iBlockBegin+1,j},'^[a-zA-Z_0-9_|_@]+','once','match');
            bVarTypes{1,j} = regexp(file{iBlockBegin+1,j},'(?<=\()[^)]*(?=\))','once','match');
            bVarUnits{1,j} = '';
        end
        
        % reading block
        block=table2array(cell2table(file((iBlockBegin+2):(iBlockEnd-1),:)));
        blockTable=array2table(block,'VariableNames',bVarNames);
        
        % creating 'data' format
        dataFormat = {'blockTable','blockName','varNames','varTypes','varValues','bVarNames','bVarTypes','bVarUnits'};
        data(blockIndex,:)={blockTable,blockName,varNames,varTypes,varValues,bVarNames,bVarTypes,bVarUnits};
        
    end
end

dataMDF=data;
save('dataMDF.mat', 'dataMDF');

%%

function measLines = convertMeasTable2Str(measTable, Delimiter)
imax=size(measTable,1);

measLines = strings(imax,1);
for i=1:imax
    measLines(i)=strjoin(string(table2array(measTable(i,:))),Delimiter);
end
end
