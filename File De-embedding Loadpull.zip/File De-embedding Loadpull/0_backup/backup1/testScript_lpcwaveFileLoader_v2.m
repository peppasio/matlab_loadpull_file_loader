clc
clear variables

fileName = 'DoE_4-5_B0009/DoE4_5_B0009_O1_LP_3p4G_80mA.LPCwave';

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Section A: import lpcwave file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

file=readcell(fileName,'FileType','text', ...
    'CommentStyle','!', ...
    'Delimiter',{'\t',' '}, ...
    'ConsecutiveDelimitersRule','join', ...
    'LeadingDelimitersRule','ignore');

file(cellfun(@(x) isa(x,'missing'), file)) = {''};

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Section B: convert file into universal 'data' format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:size(file,2)
    temp_bVarNames{1,i} = regexp(file{1,i},'^[a-zA-Z_0-9_|_@]+','once','match');
    temp_bVarUnits{1,i} = regexp(file{1,i},'(?<=\[)[a-zA-Z_0-9_%]*(?=\])','once','match');
end

blockIndex=0;

i=2;
while (i<=size(file,1))
    if (strcmp(char(string(file(i,1))),'#'))
        blockIndex=blockIndex+1;
        
        point = file{i,2};
        gamma = file{i,3};
        phase = file{i,4}; 
        
        i=i+1;
        
    else
        blockStart=i;
        k = i;
        while (~strcmp(char(string(file(k,1))),'#'))
            k=k+1;
            if (k>size(file,1))
                break
            end
        end
        blockStop=k-1;
        i = k;
        
        temp = table2array(rmmissing(cell2table(file(blockStart:blockStop,:)),2));
        block = [(temp(:,size(temp,2))-1) ones(size(temp,1),1)*point ones(size(temp,1),1)*gamma ones(size(temp,1),1)*phase temp];
        blockTable=array2table(block,'VariableNames',['Index_Pin' temp_bVarNames]);
        blockTable=movevars(blockTable,'Point','After','Phase');
        blockTable=movevars(blockTable,'Psource','Before','Gamma');
        
        blockName = "";
        
        varNames{1,1}  = 'Index_load';
        varTypes{1,1}  = 0;
        varValues{1,1} = blockIndex-1;
        
        bVarNames = blockTable.Properties.VariableNames;
        bVarTypes = num2cell(~strcmp('Point',bVarNames));
        
        for k=1:size(bVarNames,2)
            j=find(strcmp(bVarNames{1,k},temp_bVarNames));
            
            if isempty(j)
                bVarUnits{1,k} = '';
            else
                bVarUnits{1,k} = temp_bVarUnits{1,j};
            end
        end
        
        % creating 'data' format
        dataFormat = {'blockTable','blockName','varNames','varTypes','varValues','bVarNames','bVarTypes','bVarUnits'};
        data(blockIndex,:)={blockTable,blockName,varNames,varTypes,varValues,bVarNames,bVarTypes,bVarUnits};
        
    end
end

dataLPC=data;
save('dataLPC.mat', 'dataLPC');

function measLines = convertMeasTable2Str(measTable, Delimiter)
    imax=size(measTable,1);
    
    measLines = strings(imax,1);
    for i=1:imax
        measLines(i)=strjoin(string(table2array(measTable(i,:))),Delimiter);
    end
end
