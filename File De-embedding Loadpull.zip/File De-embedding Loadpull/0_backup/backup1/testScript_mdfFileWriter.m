lineIndex=0;
delimiter = '\t';
obj=b;

for blockIndex=1:size(obj.data,1)
    blockTable = obj.data{blockIndex,1};
    blockName = obj.data{blockIndex,2};
    
    varNames = obj.data{blockIndex,3};
    varTypes = obj.data{blockIndex,4};
    varValues = obj.data{blockIndex,5};
    
    bVarNames = obj.data{blockIndex,6};
    bVarTypes = obj.data{blockIndex,7};
    bVarUnits = obj.data{blockIndex,8};
    
    for varIndex=1:size(varNames,2)
        lineIndex = lineIndex + 1;
        file{lineIndex,1} = string(['VAR ' char(varNames{1,varIndex}) '(' num2str(varTypes{1,varIndex}) ') = ' char(num2str(varValues{1,varIndex}))]);
    end
    
    lineIndex = lineIndex + 1;
    file{lineIndex,1} = string(['BEGIN ' char(blockName{1,1})]);
    
    for bVarIndex=1:size(bVarNames,2)
        bVars{1,bVarIndex} = [bVarNames{1,bVarIndex} '(' num2str(bVarTypes{1,bVarIndex}) ')'];
    end
    
    lineIndex = lineIndex + 1;
    file{lineIndex,1} = string(['% ' strjoin(bVars,delimiter)]);
    
    
    for i=1:size(blockTable,1)
        lineIndex = lineIndex + 1;
        file{lineIndex,1}=strjoin(string(table2array(blockTable(i,:))),delimiter);
    end
    
    lineIndex = lineIndex + 1;
    file{lineIndex,1} = "END ";
end



